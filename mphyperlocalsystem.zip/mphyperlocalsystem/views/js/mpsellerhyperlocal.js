/**
* 2010-2019 Webkul.
*
* NOTICE OF LICENSE
*
* All right is reserved,
* Please go through this link for complete license : https://store.webkul.com/license.html
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade this module to newer
* versions in the future. If you wish to customize this module for your
* needs please refer to https://store.webkul.com/customisation-guidelines/ for more information.
*
*  @author    Webkul IN <support@webkul.com>
*  @copyright 2010-2019 Webkul IN
*  @license   https://store.webkul.com/license.html
*/

$(document).ready(function() {
    $('#add_default_price').on('click', function() {
        $('#default_price_div').slideDown();
        $('#default_price_show').hide();
    });

    $('#cancel_default_shiprate').on('click', function() {
        $('#default_price_div').slideUp();
        $('#default_price_show').show();
    });

	$('#upload_csv-selectbutton').click(function(e){
		$('#upload_csv').trigger('click');
	});

    $(".delete_img").on("click", function(e){
        e.preventDefault();
        if (confirm(confirm_msg)) {
            window.location.href = $(this).attr('href');
        }
    });

	$('#upload_csv').change(function(e){
        var val = $(this).val();
        var file_extension = val.split('.').pop();
        var file = val.split(/[\\/]/);
        if (file_extension == 'csv') {
            $('#upload_csv-name').text(file[file.length-1]);
            return true;
        } else {
            alert('invalid File');
            return false;
        }
	});

	$('#csv_on').on('click', function(){
        $('#wk-add-ship-rate').hide();
        $('#wk-add-ship-rate .form-control').removeAttr('required');
		$('#upload_shiprate_csv').show();
	});

	$('#csv_off').on('click', function(){
		$('#upload_shiprate_csv').hide();
        $('#wk-add-ship-rate').show();
        $('#wk-add-ship-rate .form-control').attr('required', 'required');
	});

    if (typeof wk_dataTables != 'undefined') {
        $('#mp_hyperlocal_list').DataTable({
            "language": {
                "lengthMenu": display_name + " _MENU_ " + records_name,
                "zeroRecords": no_product,
                "info": show_page + " _PAGE_ " + show_of + " _PAGES_ ",
                "infoEmpty": no_record,
                "infoFiltered": "(" + filter_from + " _MAX_ " + t_record + ")",
                "sSearch": search_item,
                "oPaginate": {
                    "sPrevious": p_page,
                    "sNext": n_page
                }
            },
            "order": [
                [0, "desc"]
            ]
        });

        $('select[name="mp_hyperlocal_list_length"]').addClass('form-control-select');
    }
});
