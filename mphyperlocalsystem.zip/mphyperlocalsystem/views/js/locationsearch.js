/**
* 2010-2019 Webkul.
*
* NOTICE OF LICENSE
*
* All right is reserved,
* Please go through this link for complete license : https://store.webkul.com/license.html
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade this module to newer
* versions in the future. If you wish to customize this module for your
* needs please refer to https://store.webkul.com/customisation-guidelines/ for more information.
*
*  @author    Webkul IN <support@webkul.com>
*  @copyright 2010-2019 Webkul IN
*  @license   https://store.webkul.com/license.html
*/

$(document).ready(function() {
    $('#address').on('keyup', function(e){
        if(e.keyCode == 8) {
            $('#latitude').val('');
            $('#longitude').val('');
        }
    });

    if ($( "#address" ).length > 0) {
        var autocomplete;
        autocomplete = new google.maps.places.Autocomplete(
            /** @type {!HTMLInputElement} */(document.getElementById('address')),
            {types: ['geocode']}
        );

        autocomplete.addListener('place_changed', fillAddress);

        function fillAddress()
        {
            // Get the place details from the autocomplete object.
            var placepopup = autocomplete.getPlace();
            //var address = ($('#address').val()).split(",");
            //console.log(placepopup.address_components);
            // for (var i = 0; i < placepopup.address_components.length; i++) {
            //   var addressType = placepopup.address_components[i].types[0];
            //   if (address_Type[addressType]) {
            //     var val = placepopup.address_components[i][address_Type[addressType]];
            //     if (val == address[0]) {
            //         console.log(addressMap[addressType]);
            //         $('#address_type>option:eq('+selector[addressMap[addressType]]+')').prop('selected', true);
            //     }
            //   }
            // }
            $('#latitude').val(placepopup.geometry.location.lat());
            $('#longitude').val(placepopup.geometry.location.lng());
        }
    }
});


