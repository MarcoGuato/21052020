/**
 * 2010-2019 Webkul.
 *
 * NOTICE OF LICENSE
 *
 * All right is reserved,
 * Please go through this link for complete license : https://store.webkul.com/license.html
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future. If you wish to customize this module for your
 * needs please refer to https://store.webkul.com/customisation-guidelines/ for more information.
 *
 *  @author    Webkul IN <support@webkul.com>
 *  @copyright 2010-2019 Webkul IN
 *  @license   https://store.webkul.com/license.html
 */

$(document).ready(function () {
    var addressArray = {};
    console.log(display)
    if (display == true) {
        $('#location-modal').modal('show');
    }
    if ($("#set-address").length > 0) {
        var autocomplete;
        autocomplete = new google.maps.places.Autocomplete(
            /** @type {!HTMLInputElement} */
            (document.getElementById('set-address')), {
                types: ['geocode']
            }
        );

        autocomplete.addListener('place_changed', fillAddress);

        function fillAddress() {
            // Get the place details from the autocomplete object.
            var placepopup = autocomplete.getPlace();
            var address_Type = {
                locality: 'long_name',
                administrative_area_level_1: 'short_name',
                country: 'short_name'
            };

            $.each(placepopup.address_components, function (index, address_component) {
                if (address_Type[address_component.types[0]])
                    addressArray[address_component.types[0]] = address_component[address_Type[address_component.types[0]]];
            });
            $('#set-address').attr('data-lat', placepopup.geometry.location.lat());
            $('#set-address').attr('data-lng', placepopup.geometry.location.lng());
        }
    }

    $('#wk_location_shop').on('click', function () {
        var address = $('#set-address').val();
        var latitude = $('#set-address').attr('data-lat');
        var longitude = $('#set-address').attr('data-lng');
        if (address && latitude && longitude) {
            var conf = confirm('While changing location, your cart will be empty.');
            if (conf) {
                $.ajax({
                    url: wksetcustomerlocation,
                    data: {
                        'address': address,
                        'latitude': latitude,
                        'longitude': longitude,
                        'addressArray': JSON.stringify(addressArray)
                    },
                    type: 'POST',
                    dataType: 'json',
                    success: function (result) {
                        //var response = $.parseJSON(transport);
                        if (result.status == 'ok') {
                            location.reload();
                        } else {
                            $('.go-to-shop').before($('<span/>').text(response.msg));
                        }
                    }
                });
            }
        } else {
            $('#set-address').focus();
            $('#set-address').css('border', '1px solid red');
        }
    });
});