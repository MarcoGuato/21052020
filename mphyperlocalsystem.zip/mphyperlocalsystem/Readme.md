
- Module V5.0.2 compatible with PrestaShop V1.7.x.x and Marketplace V5.1.x
- Module V3.0.2 compatible with PrestaShop V1.6.x.x and Marketplace V3.1.x

### User Guide Documentation:
https://webkul.com/blog/prestashop-marketplace-hyperlocal-system/

### Support:
https://store.webkul.com/support.html/

### Refund:
https://store.webkul.com/refund-policy.html/
