<?php
/**
* 2010-2019 Webkul.
*
* NOTICE OF LICENSE
*
* All right is reserved,
* Please go through this link for complete license : https://store.webkul.com/license.html
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade this module to newer
* versions in the future. If you wish to customize this module for your
* needs please refer to https://store.webkul.com/customisation-guidelines/ for more information.
*
*  @author    Webkul IN <support@webkul.com>
*  @copyright 2010-2019 Webkul IN
*  @license   https://store.webkul.com/license.html
*/

class Product extends ProductCore
{
    public static function getPricesDrop(
        $id_lang,
        $page_number = 0,
        $nb_products = 10,
        $count = false,
        $order_by = null,
        $order_way = null,
        $beginning = false,
        $ending = false,
        Context $context = null
    ) {
        if (!Validate::isBool($count)) {
            die(Tools::displayError());
        }

        if (!$context) {
            $context = Context::getContext();
        }
        if ($page_number < 1) {
            $page_number = 1;
        }
        if ($nb_products < 1) {
            $nb_products = 10;
        }
        if (empty($order_by) || $order_by == 'position') {
            $order_by = 'price';
        }
        if (empty($order_way)) {
            $order_way = 'DESC';
        }
        if ($order_by == 'id_product' || $order_by == 'price' || $order_by == 'date_add' || $order_by == 'date_upd') {
            $order_by_prefix = 'product_shop';
        } elseif ($order_by == 'name') {
            $order_by_prefix = 'pl';
        }
        if (!Validate::isOrderBy($order_by) || !Validate::isOrderWay($order_way)) {
            die(Tools::displayError());
        }
        $current_date = date('Y-m-d H:i:00');
        $ids_product = Product::_getProductIdByDate((!$beginning ? $current_date : $beginning), (!$ending ? $current_date : $ending), $context);

        $tab_id_product = array();
        foreach ($ids_product as $product) {
            if (is_array($product)) {
                $tab_id_product[] = (int)$product['id_product'];
            } else {
                $tab_id_product[] = (int)$product;
            }
        }

        $front = true;
        if (!in_array($context->controller->controller_type, array('front', 'modulefront'))) {
            $front = false;
        }

        $sql_groups = '';
        if (Group::isFeatureActive()) {
            $groups = FrontController::getCurrentCustomerGroups();
            $sql_groups = ' AND EXISTS(SELECT 1 FROM `'._DB_PREFIX_.'category_product` cp
				JOIN `'._DB_PREFIX_.'category_group` cg ON (cp.id_category = cg.id_category AND cg.`id_group` '.(count($groups) ? 'IN ('.implode(',', $groups).')' : '= 1').')
				WHERE cp.`id_product` = p.`id_product`)';
        }

        if ($count) {
            $cookie = new Cookie('wkhyperlocal_cookie');
            if (Module::isInstalled('mphyperlocalsystem')
            && Module::isEnabled('mphyperlocalsystem')
            && isset($cookie->wkHyperlocalLatitude)
            && isset($cookie->wkHyperlocalLongitude)) {
                Module::getInstanceByName('mphyperlocalsystem');
                $shipAreaSeller = WkMpHyperlocalShipArea::calculateShipAreaDistance(
                    $cookie->wkHyperlocalLatitude,
                    $cookie->wkHyperlocalLongitude
                );

                if (in_array(0, $shipAreaSeller)) {
                    $isAdmin = 'OR wkmpsp.id_seller IS NULL';
                } else {
                    $isAdmin = '';
                }
                return Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('
                SELECT COUNT(DISTINCT p.`id_product`)
                FROM `'._DB_PREFIX_.'product` p
                '.Shop::addSqlAssociation('product', 'p').'
                LEFT JOIN ' . _DB_PREFIX_ . 'wk_mp_seller_product wkmpsp ON (wkmpsp.id_ps_product = p.id_product AND wkmpsp.id_ps_product > 0)
                WHERE product_shop.`active` = 1
                AND product_shop.`show_price` = 1
                AND (wkmpsp.`id_seller` IN ("'.implode('","', $shipAreaSeller).'") '.$isAdmin.' )
                '.($front ? ' AND product_shop.`visibility` IN ("both", "catalog")' : '').'
                '.((!$beginning && !$ending) ? 'AND p.`id_product` IN('.((is_array($tab_id_product) && count($tab_id_product)) ? implode(', ', $tab_id_product) : 0).')' : '').'
                '.$sql_groups);
            } else {
                return Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('
                SELECT COUNT(DISTINCT p.`id_product`)
                FROM `'._DB_PREFIX_.'product` p
                '.Shop::addSqlAssociation('product', 'p').'
                WHERE product_shop.`active` = 1
                AND product_shop.`show_price` = 1
                '.($front ? ' AND product_shop.`visibility` IN ("both", "catalog")' : '').'
                '.((!$beginning && !$ending) ? 'AND p.`id_product` IN('.((is_array($tab_id_product) && count($tab_id_product)) ? implode(', ', $tab_id_product) : 0).')' : '').'
                '.$sql_groups);
            }
        }

        if (strpos($order_by, '.') > 0) {
            $order_by = explode('.', $order_by);
            $order_by = pSQL($order_by[0]).'.`'.pSQL($order_by[1]).'`';
        }

        $cookie = new Cookie('wkhyperlocal_cookie');
        if (Module::isInstalled('mphyperlocalsystem')
        && Module::isEnabled('mphyperlocalsystem')
        && isset($cookie->wkHyperlocalLatitude)
        && isset($cookie->wkHyperlocalLongitude)) {
            Module::getInstanceByName('mphyperlocalsystem');
            $shipAreaSeller = WkMpHyperlocalShipArea::calculateShipAreaDistance(
                $cookie->wkHyperlocalLatitude,
                $cookie->wkHyperlocalLongitude
            );

            if (in_array(0, $shipAreaSeller)) {
                $isAdmin = 'OR wkmpsp.id_seller IS NULL';
            } else {
                $isAdmin = '';
            }

            $sql = '
            SELECT
                p.*, product_shop.*, stock.out_of_stock, IFNULL(stock.quantity, 0) as quantity, pl.`description`, pl.`description_short`, pl.`available_now`, pl.`available_later`,
                IFNULL(product_attribute_shop.id_product_attribute, 0) id_product_attribute,
                pl.`link_rewrite`, pl.`meta_description`, pl.`meta_keywords`, pl.`meta_title`,
                pl.`name`, image_shop.`id_image` id_image, il.`legend`, m.`name` AS manufacturer_name,
                DATEDIFF(
                    p.`date_add`,
                    DATE_SUB(
                        "'.date('Y-m-d').' 00:00:00",
                        INTERVAL '.(Validate::isUnsignedInt(Configuration::get('PS_NB_DAYS_NEW_PRODUCT')) ? Configuration::get('PS_NB_DAYS_NEW_PRODUCT') : 20).' DAY
                    )
                ) > 0 AS new
            FROM `'._DB_PREFIX_.'product` p
            '.Shop::addSqlAssociation('product', 'p').'
            LEFT JOIN `'._DB_PREFIX_.'product_attribute_shop` product_attribute_shop
                ON (p.`id_product` = product_attribute_shop.`id_product` AND product_attribute_shop.`default_on` = 1 AND product_attribute_shop.id_shop='.(int)$context->shop->id.')
            '.Product::sqlStock('p', 0, false, $context->shop).'
            LEFT JOIN `'._DB_PREFIX_.'product_lang` pl ON (
                p.`id_product` = pl.`id_product`
                AND pl.`id_lang` = '.(int)$id_lang.Shop::addSqlRestrictionOnLang('pl').'
            )
            LEFT JOIN `'._DB_PREFIX_.'image_shop` image_shop
                ON (image_shop.`id_product` = p.`id_product` AND image_shop.cover=1 AND image_shop.id_shop='.(int)$context->shop->id.')
            LEFT JOIN `'._DB_PREFIX_.'image_lang` il ON (image_shop.`id_image` = il.`id_image` AND il.`id_lang` = '.(int)$id_lang.')
            LEFT JOIN `'._DB_PREFIX_.'manufacturer` m ON (m.`id_manufacturer` = p.`id_manufacturer`)
            LEFT JOIN ' . _DB_PREFIX_ . 'wk_mp_seller_product wkmpsp ON (wkmpsp.id_ps_product = p.id_product AND wkmpsp.id_ps_product > 0)
            WHERE product_shop.`active` = 1
            AND product_shop.`show_price` = 1
            AND (wkmpsp.id_seller IN ("'.implode('","', $shipAreaSeller).'") '.$isAdmin.' )
            '.($front ? ' AND product_shop.`visibility` IN ("both", "catalog")' : '').'
            '.((!$beginning && !$ending) ? ' AND p.`id_product` IN ('.((is_array($tab_id_product) && count($tab_id_product)) ? implode(', ', $tab_id_product) : 0).')' : '').'
            '.$sql_groups.'
            ORDER BY '.(isset($order_by_prefix) ? pSQL($order_by_prefix).'.' : '').pSQL($order_by).' '.pSQL($order_way).'
            LIMIT '.(int)(($page_number-1) * $nb_products).', '.(int)$nb_products;
        } else {
            $sql = '
            SELECT
                p.*, product_shop.*, stock.out_of_stock, IFNULL(stock.quantity, 0) as quantity, pl.`description`, pl.`description_short`, pl.`available_now`, pl.`available_later`,
                IFNULL(product_attribute_shop.id_product_attribute, 0) id_product_attribute,
                pl.`link_rewrite`, pl.`meta_description`, pl.`meta_keywords`, pl.`meta_title`,
                pl.`name`, image_shop.`id_image` id_image, il.`legend`, m.`name` AS manufacturer_name,
                DATEDIFF(
                    p.`date_add`,
                    DATE_SUB(
                        "'.date('Y-m-d').' 00:00:00",
                        INTERVAL '.(Validate::isUnsignedInt(Configuration::get('PS_NB_DAYS_NEW_PRODUCT')) ? Configuration::get('PS_NB_DAYS_NEW_PRODUCT') : 20).' DAY
                    )
                ) > 0 AS new
            FROM `'._DB_PREFIX_.'product` p
            '.Shop::addSqlAssociation('product', 'p').'
            LEFT JOIN `'._DB_PREFIX_.'product_attribute_shop` product_attribute_shop
                ON (p.`id_product` = product_attribute_shop.`id_product` AND product_attribute_shop.`default_on` = 1 AND product_attribute_shop.id_shop='.(int)$context->shop->id.')
            '.Product::sqlStock('p', 0, false, $context->shop).'
            LEFT JOIN `'._DB_PREFIX_.'product_lang` pl ON (
                p.`id_product` = pl.`id_product`
                AND pl.`id_lang` = '.(int)$id_lang.Shop::addSqlRestrictionOnLang('pl').'
            )
            LEFT JOIN `'._DB_PREFIX_.'image_shop` image_shop
                ON (image_shop.`id_product` = p.`id_product` AND image_shop.cover=1 AND image_shop.id_shop='.(int)$context->shop->id.')
            LEFT JOIN `'._DB_PREFIX_.'image_lang` il ON (image_shop.`id_image` = il.`id_image` AND il.`id_lang` = '.(int)$id_lang.')
            LEFT JOIN `'._DB_PREFIX_.'manufacturer` m ON (m.`id_manufacturer` = p.`id_manufacturer`)
            WHERE product_shop.`active` = 1
            AND product_shop.`show_price` = 1
            '.($front ? ' AND product_shop.`visibility` IN ("both", "catalog")' : '').'
            '.((!$beginning && !$ending) ? ' AND p.`id_product` IN ('.((is_array($tab_id_product) && count($tab_id_product)) ? implode(', ', $tab_id_product) : 0).')' : '').'
            '.$sql_groups.'
            ORDER BY '.(isset($order_by_prefix) ? pSQL($order_by_prefix).'.' : '').pSQL($order_by).' '.pSQL($order_way).'
            LIMIT '.(int)(($page_number-1) * $nb_products).', '.(int)$nb_products;
        }


        $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);

        if (!$result) {
            return false;
        }

        if ($order_by == 'price') {
            Tools::orderbyPrice($result, $order_way);
        }

        return Product::getProductsProperties($id_lang, $result);
    }

    public static function getNewProducts($id_lang, $page_number = 0, $nb_products = 10, $count = false, $order_by = null, $order_way = null, Context $context = null)
    {
        $now = date('Y-m-d') . ' 00:00:00';
        if (!$context) {
            $context = Context::getContext();
        }

        $front = true;
        if (!in_array($context->controller->controller_type, array('front', 'modulefront'))) {
            $front = false;
        }

        if ($page_number < 1) {
            $page_number = 1;
        }
        if ($nb_products < 1) {
            $nb_products = 10;
        }
        if (empty($order_by) || $order_by == 'position') {
            $order_by = 'date_add';
        }
        if (empty($order_way)) {
            $order_way = 'DESC';
        }
        if ($order_by == 'id_product' || $order_by == 'price' || $order_by == 'date_add' || $order_by == 'date_upd') {
            $order_by_prefix = 'product_shop';
        } elseif ($order_by == 'name') {
            $order_by_prefix = 'pl';
        }
        if (!Validate::isOrderBy($order_by) || !Validate::isOrderWay($order_way)) {
            die(Tools::displayError());
        }

        $sql_groups = '';
        if (Group::isFeatureActive()) {
            $groups = FrontController::getCurrentCustomerGroups();
            $sql_groups = ' AND EXISTS(SELECT 1 FROM `'._DB_PREFIX_.'category_product` cp
				JOIN `'._DB_PREFIX_.'category_group` cg ON (cp.id_category = cg.id_category AND cg.`id_group` '.(count($groups) ? 'IN ('.implode(',', $groups).')' : '= '.(int)Configuration::get('PS_UNIDENTIFIED_GROUP')).')
				WHERE cp.`id_product` = p.`id_product`)';
        }

        if (strpos($order_by, '.') > 0) {
            $order_by = explode('.', $order_by);
            $order_by_prefix = $order_by[0];
            $order_by = $order_by[1];
        }

        $nb_days_new_product = (int) Configuration::get('PS_NB_DAYS_NEW_PRODUCT');

        if ($count) {
            $cookie = new Cookie('wkhyperlocal_cookie');
            if (Module::isInstalled('mphyperlocalsystem')
            && Module::isEnabled('mphyperlocalsystem')
            && isset($cookie->wkHyperlocalLatitude)
            && isset($cookie->wkHyperlocalLongitude)) {
                Module::getInstanceByName('mphyperlocalsystem');
                $shipAreaSeller = WkMpHyperlocalShipArea::calculateShipAreaDistance(
                    $cookie->wkHyperlocalLatitude,
                    $cookie->wkHyperlocalLongitude
                );

                if (in_array(0, $shipAreaSeller)) {
                    $isAdmin = 'OR wkmpsp.id_seller IS NULL';
                } else {
                    $isAdmin = '';
                }

                $sql = 'SELECT COUNT(p.`id_product`) AS nb
                        FROM `'._DB_PREFIX_.'product` p
                        '.Shop::addSqlAssociation('product', 'p').'
                        LEFT JOIN ' . _DB_PREFIX_ . 'wk_mp_seller_product wkmpsp ON (wkmpsp.id_ps_product = p.id_product AND wkmpsp.id_ps_product > 0)
                        WHERE product_shop.`active` = 1
                        AND (wkmpsp.`id_seller` IN ("'.implode('","', $shipAreaSeller).'") '.$isAdmin.' )
                        AND product_shop.`date_add` > "'.date('Y-m-d', strtotime('-'.$nb_days_new_product.' DAY')).'"
                        '.($front ? ' AND product_shop.`visibility` IN ("both", "catalog")' : '').'
                        '.$sql_groups;
                return (int)Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue($sql);
            } else {
                $sql = 'SELECT COUNT(p.`id_product`) AS nb
                        FROM `'._DB_PREFIX_.'product` p
                        '.Shop::addSqlAssociation('product', 'p').'
                        WHERE product_shop.`active` = 1
                        AND product_shop.`date_add` > "'.date('Y-m-d', strtotime('-'.$nb_days_new_product.' DAY')).'"
                        '.($front ? ' AND product_shop.`visibility` IN ("both", "catalog")' : '').'
                        '.$sql_groups;
                return (int)Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue($sql);
            }
        }
        $sql = new DbQuery();
        $sql->select(
            'p.*, product_shop.*, stock.out_of_stock, IFNULL(stock.quantity, 0) as quantity, pl.`description`, pl.`description_short`, pl.`link_rewrite`, pl.`meta_description`,
			pl.`meta_keywords`, pl.`meta_title`, pl.`name`, pl.`available_now`, pl.`available_later`, image_shop.`id_image` id_image, il.`legend`, m.`name` AS manufacturer_name,
			(DATEDIFF(product_shop.`date_add`,
				DATE_SUB(
					"'.$now.'",
					INTERVAL '.$nb_days_new_product.' DAY
				)
			) > 0) as new'
        );

        $sql->from('product', 'p');
        $sql->join(Shop::addSqlAssociation('product', 'p'));
        $sql->leftJoin('product_lang', 'pl', '
			p.`id_product` = pl.`id_product`
			AND pl.`id_lang` = '.(int)$id_lang.Shop::addSqlRestrictionOnLang('pl')
        );
        $sql->leftJoin('image_shop', 'image_shop', 'image_shop.`id_product` = p.`id_product` AND image_shop.cover=1 AND image_shop.id_shop='.(int)$context->shop->id);
        $sql->leftJoin('image_lang', 'il', 'image_shop.`id_image` = il.`id_image` AND il.`id_lang` = '.(int)$id_lang);
        $sql->leftJoin('manufacturer', 'm', 'm.`id_manufacturer` = p.`id_manufacturer`');
        $cookie = new Cookie('wkhyperlocal_cookie');
        if (Module::isInstalled('mphyperlocalsystem')
        && Module::isEnabled('mphyperlocalsystem')
        && isset($cookie->wkHyperlocalLatitude)
        && isset($cookie->wkHyperlocalLongitude)) {
            Module::getInstanceByName('mphyperlocalsystem');
            $shipAreaSeller = WkMpHyperlocalShipArea::calculateShipAreaDistance(
                $cookie->wkHyperlocalLatitude,
                $cookie->wkHyperlocalLongitude
            );

            if (in_array(0, $shipAreaSeller)) {
                $isAdmin = 'OR wkmpsp.id_seller IS NULL';
            } else {
                $isAdmin = '';
            }
            $sql->leftJoin('wk_mp_seller_product', 'wkmpsp', 'wkmpsp.`id_ps_product` = p.`id_product` AND wkmpsp.id_ps_product > 0');
            $sql->where('(wkmpsp.id_seller IN ("'.implode('","', $shipAreaSeller).'") '.$isAdmin.' )');
        }

        $sql->where('product_shop.`active` = 1');
        if ($front) {
            $sql->where('product_shop.`visibility` IN ("both", "catalog")');
        }
        $sql->where('product_shop.`date_add` > "'.date('Y-m-d', strtotime('-'.$nb_days_new_product.' DAY')).'"');
        if (Group::isFeatureActive()) {
            $groups = FrontController::getCurrentCustomerGroups();
            $sql->where('EXISTS(SELECT 1 FROM `'._DB_PREFIX_.'category_product` cp
				JOIN `'._DB_PREFIX_.'category_group` cg ON (cp.id_category = cg.id_category AND cg.`id_group` '.(count($groups) ? 'IN ('.implode(',', $groups).')' : '= 1').')
				WHERE cp.`id_product` = p.`id_product`)');
        }

        $sql->orderBy((isset($order_by_prefix) ? pSQL($order_by_prefix).'.' : '').'`'.pSQL($order_by).'` '.pSQL($order_way));
        $sql->limit($nb_products, (int)(($page_number-1) * $nb_products));

        if (Combination::isFeatureActive()) {
            $sql->select('product_attribute_shop.minimal_quantity AS product_attribute_minimal_quantity, IFNULL(product_attribute_shop.id_product_attribute,0) id_product_attribute');
            $sql->leftJoin('product_attribute_shop', 'product_attribute_shop', 'p.`id_product` = product_attribute_shop.`id_product` AND product_attribute_shop.`default_on` = 1 AND product_attribute_shop.id_shop='.(int)$context->shop->id);
        }
        $sql->join(Product::sqlStock('p', 0));

        $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);

        if (!$result) {
            return false;
        }

        if ($order_by == 'price') {
            Tools::orderbyPrice($result, $order_way);
        }
        $products_ids = array();
        foreach ($result as $row) {
            $products_ids[] = $row['id_product'];
        }
        // Thus you can avoid one query per product, because there will be only one query for all the products of the cart
        Product::cacheFrontFeatures($products_ids, $id_lang);
        return Product::getProductsProperties((int)$id_lang, $result);
    }
}
