<?php
/**
* 2010-2019 Webkul.
*
* NOTICE OF LICENSE
*
* All right is reserved,
* Please go through this link for complete license : https://store.webkul.com/license.html
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade this module to newer
* versions in the future. If you wish to customize this module for your
* needs please refer to https://store.webkul.com/customisation-guidelines/ for more information.
*
*  @author    Webkul IN <support@webkul.com>
*  @copyright 2010-2019 Webkul IN
*  @license   https://store.webkul.com/license.html
*/

class CheckoutAddressesStep extends CheckoutAddressesStepCore
{
    public function handleRequest(array $requestParams = array())
    {
        $addressStep = parent::handleRequest($requestParams);
        $idAddress = $addressStep->getCheckoutSession()->getIdAddressDelivery();
        if (Module::isInstalled('mphyperlocalsystem') && Module::isEnabled('mphyperlocalsystem')) {
            $cookie = new Cookie('wkhyperlocal_cookie');
            if (!isset($cookie->wkHyperlocalAddress) && !isset($cookie->wkHyperAddresComponent)) {
                $addressStep->step_is_complete = false;
                $this->context->controller->errors[] = 'Please set your location';
                return $addressStep;
            }

            $addressComponent = Tools::jsonDecode($cookie->wkHyperAddresComponent);
            $objAddress = new Address($idAddress);
            if (!Validate::isLoadedObject($objAddress)) {
                return false;
            }

            $error = false;
            $countryIsoCode = Country::getIsoById($objAddress->id_country);
            if ($countryIsoCode == $addressComponent->country) {
                if ($objAddress->id_state) {
                    $state = new State($objAddress->id_state);
                    if (!($state->iso_code == $addressComponent->administrative_area_level_1
                    && $state->id_country == $objAddress->id_country)) {
                        $error = true;
                    }
                }
                // if (!($objAddress->city && strtolower($objAddress->city) == strtolower($addressComponent->locality))) {
                //     $error = true;
                // }
            } else {
                $error = true;
            }

            if ($error) {
                $addressStep->step_is_complete = false;
                $this->context->controller->errors[] = 'Shipping address should belong to the selected location';
            } else {
                $address = AddressFormat::generateAddress($objAddress, array('avoid' => array('firstname', 'lastname', 'vat_number', 'phone', 'company')), ' ');
                $objShipArea = new WkMpHyperlocalShipArea();
                $customerLatLng = $objShipArea->getCustomerLatLngByCustomerAddress($address);
                if (!$customerLatLng) {
                    $addressStep->step_is_complete = false;
                    $this->context->controller->errors[] = 'Shipping address is not valid';
                } else {
                    $sellerlocation = WkMpHyperlocalShipArea::calculateShipAreaDistance($customerLatLng['latitude'], $customerLatLng['longitude']);

                    foreach ($this->context->cart->getProducts() as $product) {
                        $sellerProduct = WkMpSellerProduct::getSellerProductByPsIdProduct($product['id_product']);
                        $idSeller = $sellerProduct ? $sellerProduct['id_seller'] : 0;
                        if (!in_array($idSeller, $sellerlocation)) {
                            $addressStep->step_is_complete = false;
                            $this->context->controller->errors[] = 'Product(s) are not available at this selected address';
                            break;
                        }
                    }
                }
            }
        }

        return $addressStep;
    }
}
