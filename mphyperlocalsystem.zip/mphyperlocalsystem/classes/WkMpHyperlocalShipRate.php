<?php
/**
* 2010-2019 Webkul.
*
* NOTICE OF LICENSE
*
* All right is reserved,
* Please go through this link for complete license : https://store.webkul.com/license.html
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade this module to newer
* versions in the future. If you wish to customize this module for your
* needs please refer to https://store.webkul.com/customisation-guidelines/ for more information.
*
*  @author    Webkul IN <support@webkul.com>
*  @copyright 2010-2019 Webkul IN
*  @license   https://store.webkul.com/license.html
*/

class WkMpHyperlocalShipRate extends ObjectModel
{
    public $id_seller;
    public $distance_from;
    public $distance_to;
    public $weight_from;
    public $weight_to;
    public $price;
    public $date_add;
    public $date_upd;

    public static $definition = array(
        'table' => 'wk_mp_hyl_ship_rate',
        'primary' => 'id',
        'fields' => array(
            'id_seller' => array('type' => self::TYPE_INT, 'required' => true),
            'distance_from' => array('type' => self::TYPE_FLOAT, 'required' => true),
            'distance_to' => array('type' => self::TYPE_FLOAT, 'required' => true),
            'weight_from' => array('type' => self::TYPE_FLOAT, 'required' => true,),
            'weight_to' => array('type' => self::TYPE_FLOAT, 'required' => true,),
            'price' => array('type' => self::TYPE_FLOAT, 'validate' => 'isPrice', 'required' => true,),
            'date_add' => array('type' => self::TYPE_DATE, 'validate' => 'isDateFormat', 'required' => false),
            'date_upd' => array('type' => self::TYPE_DATE, 'validate' => 'isDateFormat', 'required' => false),
        ),
    );

    public static function getSellerShipRate($idSeller)
    {
        return Db::getInstance()->executeS(
            'SELECT * FROM `'._DB_PREFIX_.'wk_mp_hyl_ship_rate`
                WHERE `id_seller` = '.(int) $idSeller
        );
    }

    public static function deleteShipRateByIdSeller($idSeller)
    {
        Db::getInstance()->delete('wk_mp_hyl_ship_rate', 'id_seller = '.(int) $idSeller);
    }

    public static function claculateShipRate($idSeller, $distance, $weignt)
    {
        $cost = Db::getInstance()->getValue(
            'SELECT `price` FROM `'._DB_PREFIX_.'wk_mp_hyl_ship_rate`
                WHERE `id_seller` = '.(int) $idSeller.'
                AND `distance_from` <= '.$distance.'
                AND `distance_to` >= '.$distance.'
                AND `weight_from` <= '.$weignt.'
                AND `weight_to` >= '.$weignt
        );

        if ($cost) {
            return Tools::convertPrice($cost);
        } else {
            if (Configuration::get('WK_MP_HYPERLOCAL_OUT_OF_RANGE') == 1) {
                $objShipRate = new self();
                $defaultPrice = $objShipRate->getDefaultPriceByIdSeller($idSeller);
                if ($defaultPrice) {
                    return Tools::convertPrice($defaultPrice['price']);
                } else {
                    return Tools::convertPrice(Configuration::get('WK_MP_HYPERLOCAL_OUT_OF_RANGE_PRICE'));
                }
            } else {
                return false;
            }
        }
    }

    public static function validateCsvHeader($headerArray, $isAdmin = false)
    {
        $fields = array('distance_from', 'distance_to', 'weight_from', 'weight_to', 'price');

        if ($isAdmin) {
            $fields[] = 'id_seller';
        }

        if ($headerArray) {
            foreach ($fields as $field) {
                if (!in_array($field, $headerArray)) {
                    return false;
                }
            }
        }

        return true;
    }

    public function getDefaultPriceByIdSeller($idSeller)
    {
        return Db::getInstance()->getRow(
            'SELECT * FROM `'._DB_PREFIX_.'wk_mp_hyl_default_ship_rate`
                WHERE `id_seller` = '.(int) $idSeller
        );
    }

    public function updateDefaultShipRate($idSeller, $price)
    {
        $detail = $this->getDefaultPriceByIdSeller($idSeller);
        if ($detail) {
            Db::getInstance()->execute(
                'UPDATE `'._DB_PREFIX_.'wk_mp_hyl_default_ship_rate`
                SET `price` = '.$price.' WHERE `id` = '.(int) $detail['id']
            );
        } else {
            Db::getInstance()->insert(
                'wk_mp_hyl_default_ship_rate',
                array('id_seller' => $idSeller, 'price' => $price)
            );
        }
    }
}
