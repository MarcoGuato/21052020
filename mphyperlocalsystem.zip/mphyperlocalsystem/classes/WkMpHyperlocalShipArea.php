<?php
/**
* 2010-2019 Webkul.
*
* NOTICE OF LICENSE
*
* All right is reserved,
* Please go through this link for complete license : https://store.webkul.com/license.html
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade this module to newer
* versions in the future. If you wish to customize this module for your
* needs please refer to https://store.webkul.com/customisation-guidelines/ for more information.
*
*  @author    Webkul IN <support@webkul.com>
*  @copyright 2010-2019 Webkul IN
*  @license   https://store.webkul.com/license.html
*/

class WkMpHyperlocalShipArea extends ObjectModel
{
    public $id_seller;
    public $address;
    public $latitude;
    public $longitude;
    public $active;
    public $date_add;
    public $date_upd;

    public static $definition = array(
        'table' => 'wk_mp_hyl_ship_area',
        'primary' => 'id',
        'fields' => array(
            'id_seller' => array('type' => self::TYPE_INT, 'required' => true),
            'address' => array('type' => self::TYPE_STRING, 'required' => true),
            'latitude' => array('type' => self::TYPE_FLOAT, 'required' => true),
            'longitude' => array('type' => self::TYPE_FLOAT, 'required' => true,),
            'active' => array('type' => self::TYPE_BOOL, 'validate' => 'isBool'),
            'date_add' => array('type' => self::TYPE_DATE, 'validate' => 'isDateFormat', 'required' => false),
            'date_upd' => array('type' => self::TYPE_DATE, 'validate' => 'isDateFormat', 'required' => false),
        ),
    );

    public static function getSellerShipArea($idSeller)
    {
        return Db::getInstance()->executeS(
            'SELECT * FROM `'._DB_PREFIX_.'wk_mp_hyl_ship_area`
                WHERE `id_seller` = '.(int) $idSeller
        );
    }

    public static function deleteShipAreaByIdSeller($idSeller)
    {
        Db::getInstance()->delete('wk_mp_hyl_ship_area', 'id_seller = '.(int) $idSeller);
    }

    public static function calculateShipAreaDistance($latitude, $longitude)
    {
        $distance = Configuration::get('WK_MP_HYPERLOCAL_DISTANCE');
        $unit = Configuration::get('WK_MP_HYPERLOCAL_RADIUS_UNIT');

        if ($unit == 1) {
            $type = 3959;
        } else {
            $type = 6371;
        }

        $sql = 'SELECT *, ( '.$type.' * acos( cos( radians('.$latitude.') ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians('.$longitude.') ) + sin( radians('.$latitude.') ) * sin( radians( latitude ) ) ) ) AS distance FROM `'._DB_PREFIX_.'wk_mp_hyl_ship_area` WHERE `active` = 1 HAVING `distance` <= '.$distance;
        $shipAreaSeller = Db::getInstance()->executeS($sql);

        return array_unique(array_column($shipAreaSeller, 'id_seller'));
    }

    public function calculateMinimumDistaceByCustomerAddress($latitude, $longitude, $idSeller)
    {
        $distance = Configuration::get('WK_MP_HYPERLOCAL_DISTANCE');
        $unit = Configuration::get('WK_MP_HYPERLOCAL_RADIUS_UNIT');

        if ($unit == 1) {
            $type = 3959; // For Mile
        } else {
            $type = 6371; // for kilometer
        }

        return Db::getInstance()->getValue(
            'SELECT MIN( '.$type.' * acos( cos( radians('.$latitude.') ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians('.$longitude.') ) + sin( radians('.$latitude.') ) * sin( radians( latitude ) ) ) ) AS distance FROM `'._DB_PREFIX_.'wk_mp_hyl_ship_area`
            WHERE `id_seller` = '.(int) $idSeller.'
            AND `active` = 1
            HAVING distance <= ' .$distance
        );
    }

    public function getCustomerLatLngByCustomerAddress($address)
    {
        $mpGoogleApiKey = Configuration::get('WK_MP_GOOGLE_API_KEY');
        $json = Tools::file_get_contents('https://maps.google.com/maps/api/geocode/json?key='.$mpGoogleApiKey.'&address='.urlencode($address).'&sensor=false');
        $json = json_decode($json);

        if ($json->results && $json->status != 'ZERO_RESULTS') {
            $latitude = $json->results[0]->geometry->location->lat;
            $longitude = $json->results[0]->geometry->location->lng;
            return array('latitude' => $latitude, 'longitude' => $longitude);
        }

        return false;
    }

    public function checkCustomerDistanceByAddress($address, $sellerProductInformation)
    {
        $customerLatLng = $this->getCustomerLatLngByCustomerAddress($address);
        if (!$customerLatLng) {
            return false;
        }

        $cost = 0;
        foreach ($sellerProductInformation as $key => $weight) {
            $distance  = $this->calculateMinimumDistaceByCustomerAddress(
                $customerLatLng['latitude'],
                $customerLatLng['longitude'],
                $key
            );

            if (is_bool($distance) === false) {
                $sellerHyperlocalCost = WkMpHyperlocalShipRate::claculateShipRate($key, $distance, $weight);
                if ($sellerHyperlocalCost) {
                    $cost += $sellerHyperlocalCost;
                } else {
                    return false;
                }
            }
        }

        return $cost;
    }

    public function getSellerWiseHyperlocalCost($address, $sellerProductInformation)
    {
        $customerLatLng = $this->getCustomerLatLngByCustomerAddress($address);

        if (!$customerLatLng) {
            return false;
        }

        $cost = array();
        foreach ($sellerProductInformation as $key => $weight) {
            $idSeller = 0;
            if ($key != 0) {
                $seller = WkMpSeller::getSellerDetailByCustomerId($key);
                $idSeller = $seller['id_seller'];
            }

            $distance  = $this->calculateMinimumDistaceByCustomerAddress(
                $customerLatLng['latitude'],
                $customerLatLng['longitude'],
                $idSeller
            );

            if (is_bool($distance) === false) {
                if ($key == 0) {
                    $cost['admin'] = WkMpHyperlocalShipRate::claculateShipRate($key, $distance, $weight);
                } else {
                    $cost[$key] = WkMpHyperlocalShipRate::claculateShipRate($idSeller, $distance, $weight);
                }
            }
        }

        return $cost;
    }
}
