<?php
/**
* 2010-2019 Webkul.
*
* NOTICE OF LICENSE
*
* All right is reserved,
* Please go through this link for complete license : https://store.webkul.com/license.html
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade this module to newer
* versions in the future. If you wish to customize this module for your
* needs please refer to https://store.webkul.com/customisation-guidelines/ for more information.
*
*  @author    Webkul IN <support@webkul.com>
*  @copyright 2010-2019 Webkul IN
*  @license   https://store.webkul.com/license.html
*/

class MpHyperlocalSystemDb
{
    public function createTable()
    {
        $mpSuccess = true;
        $mpDatabaseInstance = Db::getInstance();
        if ($tableQueries = $this->getMpTableQueries()) {
            foreach ($tableQueries as $mpQuery) {
                $mpSuccess &= $mpDatabaseInstance->execute(trim($mpQuery));
            }
        }

        return $mpSuccess;
    }

    private function getMpTableQueries()
    {
        return array(
            "CREATE TABLE IF NOT EXISTS `"._DB_PREFIX_."wk_mp_hyl_ship_area` (
                `id` int(10) unsigned NOT NULL auto_increment,
                `id_seller` int(11) NOT NULL,
                `address` text,
                `latitude` decimal(13,6) DEFAULT NULL,
                `longitude` decimal(13,6) DEFAULT NULL,
                `active` tinyint(1) NOT NULL,
                `date_add` datetime NOT NULL,
                `date_upd` datetime NOT NULL,
                PRIMARY KEY  (`id`)
            ) ENGINE="._MYSQL_ENGINE_." DEFAULT CHARSET=utf8",
            "CREATE TABLE IF NOT EXISTS `"._DB_PREFIX_."wk_mp_hyl_ship_rate` (
                `id` int(10) unsigned NOT NULL auto_increment,
                `id_seller` int(11) NOT NULL,
                `distance_from` decimal(20,4) NOT NULL DEFAULT '0.000000',
                `distance_to` decimal(20,4) NOT NULL DEFAULT '0.000000',
                `weight_from` decimal(20,4) NOT NULL DEFAULT '0.000000',
                `weight_to` decimal(20,6) NOT NULL DEFAULT '0.000000',
                `price` decimal(20,6) DEFAULT '0.000000',
                `date_add` datetime NOT NULL,
                `date_upd` datetime NOT NULL,
                PRIMARY KEY  (`id`)
            ) ENGINE="._MYSQL_ENGINE_." DEFAULT CHARSET=utf8",
            "CREATE TABLE IF NOT EXISTS `"._DB_PREFIX_."wk_mp_hyl_default_ship_rate` (
                `id` int(10) unsigned NOT NULL auto_increment,
                `id_seller` int(11) NOT NULL,
                `price` decimal(20,6) DEFAULT '0.000000',
                PRIMARY KEY  (`id`)
            ) ENGINE="._MYSQL_ENGINE_." DEFAULT CHARSET=utf8",
        );
    }

    public function deleteTable()
    {
        return Db::getInstance()->execute(
            'DROP TABLE IF EXISTS
            `'._DB_PREFIX_.'wk_mp_hyl_ship_area`,
            `'._DB_PREFIX_.'wk_mp_hyl_ship_rate`,
            `'._DB_PREFIX_.'wk_mp_hyl_default_ship_rate`'
        );
    }
}
