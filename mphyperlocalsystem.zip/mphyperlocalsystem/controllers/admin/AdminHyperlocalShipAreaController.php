<?php
/**
* 2010-2019 Webkul.
*
* NOTICE OF LICENSE
*
* All right is reserved,
* Please go through this link for complete license : https://store.webkul.com/license.html
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade this module to newer
* versions in the future. If you wish to customize this module for your
* needs please refer to https://store.webkul.com/customisation-guidelines/ for more information.
*
*  @author    Webkul IN <support@webkul.com>
*  @copyright 2010-2019 Webkul IN
*  @license   https://store.webkul.com/license.html
*/

class AdminHyperlocalShipAreaController extends ModuleAdminController
{
    public function __construct()
    {
        $this->context = Context::getContext();
        $this->bootstrap = true;
        $this->table = 'wk_mp_hyl_ship_area';
        $this->className = 'WkMpHyperlocalShipArea';
        $this->identifier = 'id';

        $this->addRowAction('edit');
        $this->addRowAction('delete');

        $customerInfo = WkMpSeller::getAllSeller();
        $this->customerInfoArray[0] = 'Admin';
        //array_unshift($customerInfo, array('id_seller' => 0, 'shop_name_unique' => 'Admin'));
        if ($customerInfo) {
            foreach ($customerInfo as $seller) {
                $this->customerInfoArray[$seller['id_seller']] = $seller['shop_name_unique'];
            }
        }

        parent::__construct();

        $this->fields_list = array(
            'id' => array(
                'title' => $this->l('Id') ,
                'align' => 'center',
                'class' => 'fixed-width-xs',
            ),
            'id_seller' => array(
                'title' => $this->l('Unique Shop Name') ,
                'type' => 'select',
                'align' => 'text-center',
                'list' => $this->customerInfoArray,
                'filter_key' => 'id_seller',
                'filter_type' => 'int',
                'callback' => 'getShopName'
            ),
            'address' => array(
                'title' => $this->l('Address') ,
                'align' => 'center',
            ),
            'latitude' => array(
                'title' => $this->l('Latitude') ,
                'align' => 'center',
            ),
            'longitude' => array(
                'title' => $this->l('Longitude') ,
                'align' => 'center',
            ),
            'active' => array(
                'title' => $this->l('Status'),
                'type' => 'bool',
                'active' => 'status',
                'orderby' => false,
            ),
        );

        $this->bulk_actions = array(
            'delete' => array(
                'text' => $this->l('Delete selected'),
                'icon' => 'icon-trash',
                'confirm' => $this->l('Delete selected items?'),
            ),
        );
    }

    public function getShopName($value)
    {
        if ($value) {
            $sellerDetail = WkMpSeller::getSeller($value);
            if ($sellerDetail) {
                return $sellerDetail['shop_name_unique'];
            }
        } else {
            return $this->l('Admin');
        }

        return false;
    }

    public function initToolBar()
    {
        if ($this->display != 'add') {
            parent::initToolBar();
            $this->page_header_toolbar_btn['new'] = array(
                'href' => self::$currentIndex.'&add'.$this->table.'&token='.$this->token,
                'desc' => $this->l('Add new ship area'),
            );
        }
    }

    public function renderForm()
    {
        $this->initToolbar();
        $getAllSeller = WkMpSeller::getAllSeller();
        $customerInfo = array(array('id_seller' => 0, 'shop_name_unique' => 'Admin'));
        $disabled = true;
        if ($getAllSeller) {
            $customerInfo = array_merge($customerInfo, $getAllSeller);
        }

        if ($this->display == 'add') {
            $disabled = false;
        }

        $this->fields_form = array(
            'tinymce' => true,
            'legend' => array(
                'title' => $this->l('Manage ship area'),
                'icon' => 'icon-pencil'
            ),
            'input' => array(
                array(
                    'type' => 'select',
                    'label' => 'Choose Seller',
                    'name' => 'id_seller',
                    'class' => 'fixed-width-xxl',
                    'disabled' => $disabled,
                    'options' => array(
                        'query' => $customerInfo,
                        'id' => 'id_seller',
                        'name' => 'shop_name_unique'
                    ),
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Address'),
                    'name' => 'address',
                    'required' => true,
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Latitude'),
                    'name' => 'latitude',
                    'readonly' => true,
                    'required' => true,
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Longitude'),
                    'name' => 'longitude',
                    'readonly' => true,
                    'required' => true,
                ),
                array(
                    'type' => 'switch',
                    'label' => $this->l('Status'),
                    'name' => 'active',
                    'required' => false,
                    'is_bool' => true,
                    'values' => array(
                        array(
                            'id' => 'active_on',
                            'value' => 1,
                            'label' => $this->l('Enabled')
                        ),
                        array(
                            'id' => 'active_off',
                            'value' => 0,
                            'label' => $this->l('Disabled')
                        )
                    )
                )
            ),
            'submit' => array(
                'title' => $this->l('Save'),
            )
        );

        return parent::renderForm();
    }

    public function processSave()
    {
        $_POST['latitude'] = preg_replace('/\.(\d{6}).*/', '.$1', Tools::getValue('latitude'));
        $_POST['longitude'] = preg_replace('/\.(\d{6}).*/', '.$1', Tools::getValue('longitude'));
        return parent::processSave();
    }

    public function setMedia()
    {
        parent::setMedia();

        $language = $this->context->language;
        $country = $this->context->country;
        $mpGoogleApiKey = Configuration::get('WK_MP_GOOGLE_API_KEY');

        $this->context->controller->addJs("https://maps.googleapis.com/maps/api/js?key=$mpGoogleApiKey&libraries=places&language=$language->iso_code&region=$country->iso_code&v=3.31");

        $this->context->controller->addJS(_MODULE_DIR_.'mphyperlocalsystem/views/js/locationsearch.js');
    }
}
