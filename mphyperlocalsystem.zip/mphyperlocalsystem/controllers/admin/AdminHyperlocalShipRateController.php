<?php
/**
* 2010-2019 Webkul.
*
* NOTICE OF LICENSE
*
* All right is reserved,
* Please go through this link for complete license : https://store.webkul.com/license.html
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade this module to newer
* versions in the future. If you wish to customize this module for your
* needs please refer to https://store.webkul.com/customisation-guidelines/ for more information.
*
*  @author    Webkul IN <support@webkul.com>
*  @copyright 2010-2019 Webkul IN
*  @license   https://store.webkul.com/license.html
*/

class AdminHyperlocalShipRateController extends ModuleAdminController
{
    public function __construct()
    {
        $this->context = Context::getContext();
        $this->bootstrap = true;
        $this->table = 'wk_mp_hyl_ship_rate';
        $this->className = 'WkMpHyperlocalShipRate';
        $this->identifier = 'id';

        $this->addRowAction('edit');
        $this->addRowAction('delete');

        $customerInfo = WkMpSeller::getAllSeller();
        $this->customerInfoArray[0] = 'Admin';
        //array_unshift($customerInfo, array('id_seller' => 0, 'shop_name_unique' => 'Admin'));
        if ($customerInfo) {
            foreach ($customerInfo as $seller) {
                $this->customerInfoArray[$seller['id_seller']] = $seller['shop_name_unique'];
            }
        }

        parent::__construct();

        $this->fields_list = array(
            'id' => array(
                'title' => $this->l('Id') ,
                'align' => 'center',
                'class' => 'fixed-width-xs',
            ),
            'id_seller' => array(
                'title' => $this->l('Unique Shop Name') ,
                'type' => 'select',
                'align' => 'text-center',
                'list' => $this->customerInfoArray,
                'filter_key' => 'id_seller',
                'filter_type' => 'int',
                'callback' => 'getShopName'
            ),
            'distance_from' => array(
                'title' => $this->l('From distance') ,
                'align' => 'center',
            ),
            'distance_to' => array(
                'title' => $this->l('To distance') ,
                'align' => 'center',
            ),
            'weight_from' => array(
                'title' => $this->l('From weight') ,
                'align' => 'center',
            ),
            'weight_to' => array(
                'title' => $this->l('To weight') ,
                'align' => 'center',
            ),
            'price' => array(
                'title' => $this->l('Shipping cost') ,
                'align' => 'center',
                'type' => 'price',
            ),
        );

        $this->bulk_actions = array(
            'delete' => array(
                'text' => $this->l('Delete selected'),
                'icon' => 'icon-trash',
                'confirm' => $this->l('Delete selected items?'),
            ),
        );
    }

    public function getShopName($value)
    {
        if ($value) {
            $sellerDetail = WkMpSeller::getSeller($value);
            if ($sellerDetail) {
                return $sellerDetail['shop_name_unique'];
            }
        } else {
            return $this->l('Admin');
        }

        return false;
    }

    public function initToolBar()
    {
        if ($this->display != 'add') {
            parent::initToolBar();
            $this->page_header_toolbar_btn['new'] = array(
                'href' => self::$currentIndex.'&add'.$this->table.'&token='.$this->token,
                'desc' => $this->l('Add new shipping rate'),
            );

            $this->page_header_toolbar_btn['csv'] = array(
                'href' => self::$currentIndex.'&add'.$this->table.'&token='.$this->token.'&csv=1',
                'desc' => $this->l('Upload CSV'),
                'imgclass' => 'refresh',
            );
        }
    }

    public function renderForm()
    {
        if (Tools::getValue('csv') == 1) {
            $this->fields_form = array(
                'legend' => array(
                    'title' => $this->l('Uplaod ship rate csv'),
                    'icon' => 'icon-pencil'
                ),
                'input' => array(
                    array(
                        'type' => 'file',
                        'label' => $this->l(' CSV File'),
                        'name' => 'upload_csv',
                       'format' => 'csv',
                       'required' => true,
                       'desc' => $this->l('Please').'<a href="'._MODULE_DIR_.'mphyperlocalsystem/views/demo/admin/wk-hyperlocal-shiprate.csv">'.$this->l('Download demo CSV file for ship rate here!').'</a> '.$this->l(' CSV File must be same as Demo CSV File or just add the ship rate details in downloaded CSV File.')
                    )
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                    'name' => 'uploadshipratecsv'
                )
            );
        } else {
            $this->initToolbar();
            $getAllSeller = WkMpSeller::getAllSeller();
            $customerInfo = array(array('id_seller' => 0, 'shop_name_unique' => 'Admin'));
            $disabled = true;
            if ($getAllSeller) {
                $customerInfo = array_merge($customerInfo, $getAllSeller);
            }

            if ($this->display == 'add') {
                $disabled = false;
            }

            $this->fields_form = array(
                'legend' => array(
                    'title' => $this->l('Manage ship area'),
                    'icon' => 'icon-pencil'
                ),
                'input' => array(
                    array(
                        'type' => 'select',
                        'label' => 'Choose Seller',
                        'name' => 'id_seller',
                        'class' => 'fixed-width-xxl',
                        'disabled' => $disabled,
                        'options' => array(
                            'query' => $customerInfo,
                            'id' => 'id_seller',
                            'name' => 'shop_name_unique'
                        ),
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('From distance'),
                        'class' => 'fixed-width-xxl',
                        'name' => 'distance_from',
                        'required' => true,
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('To distance'),
                        'class' => 'fixed-width-xxl',
                        'name' => 'distance_to',
                        'required' => true,
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('From weight'),
                        'class' => 'fixed-width-xxl',
                        'name' => 'weight_from',
                        'required' => true,
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('To weight'),
                        'class' => 'fixed-width-xxl',
                        'name' => 'weight_to',
                        'required' => true,
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Shipping Cost'),
                        'name' => 'price',
                        'required' => true,
                        'class' => 'fixed-width-xxl',
                        'suffix' => $this->context->currency->sign,
                    )
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                )
            );
        }

        return parent::renderForm();
    }

    public function processSave()
    {
        if (Tools::isSubmit('uploadshipratecsv')) {
            if ($_FILES['upload_csv']['size'] > 0) {
                $extension = pathinfo($_FILES['upload_csv']['name'], PATHINFO_EXTENSION);
                if ($extension == 'csv') {
                    $file = fopen((string) $_FILES['upload_csv']['tmp_name'], 'r');
                    $headerArray = fgetcsv($file);
                    $headerValidate = WkMpHyperlocalShipRate::validateCsvHeader($headerArray, true);
                    if ($headerValidate) {
                        $shipRates = array();
                        $lineNo = 2;
                        while (($result = fgetcsv($file)) !== false) {
                            $distanceFrom = trim($result[0]);
                            $distanceTo = trim($result[1]);
                            $weightFrom = trim($result[2]);
                            $weightTo = trim($result[3]);
                            $price = trim($result[4]);
                            $idSeller = trim($result[5]);
                            $lineNoError = $this->l('Line number:') .' '. $lineNo .' '. $this->l('is having error').' ';

                            if ($idSeller == '') {
                                $this->errors[] = $lineNoError.$this->l('Seller id is required field');
                            } elseif ($idSeller != 0) {
                                $objSeller = new WkMpSeller($idSeller);
                                if (!(Validate::isLoadedObject($objSeller) && $objSeller->active)) {
                                    $this->errors[] = $lineNoError.$this->l('Seller id is not valid');
                                }
                            }

                            if ($distanceFrom == '') {
                                $this->errors[] = $lineNoError.$this->l('From distance is required field');
                            } elseif (!Validate::isUnsignedFloat($distanceFrom)) {
                                $this->errors[] = $lineNoError.$this->l('value of from distance is not valid');
                            }

                            if ($distanceTo == '') {
                                $this->errors[] = $lineNoError.$this->l('To distance is required field');
                            } elseif (!Validate::isUnsignedFloat($distanceTo)) {
                                $this->errors[] = $lineNoError.$this->l('value of to distance is not valid');
                            }

                            if ($distanceFrom >= $distanceTo) {
                                $this->errors[] = $lineNoError.$this->l('From distance must be less than to distance');
                            }

                            if ($weightFrom == '') {
                                $this->errors[] = $lineNoError.$this->l('From weight is required field');
                            } elseif (!Validate::isUnsignedFloat($weightFrom)) {
                                $this->errors[] = $lineNoError.$this->l('value of from weight is not valid');
                            }

                            if ($weightTo == '') {
                                $this->errors[] = $lineNoError.$this->l('To weight is required field');
                            } elseif (!Validate::isUnsignedFloat($weightTo)) {
                                $this->errors[] = $lineNoError.$this->l('value of to weight is not valid');
                            }

                            if ($weightFrom >= $weightTo) {
                                $this->errors[] = $this->l('From weight must be less than to weight');
                            }

                            if ($price == '') {
                                $this->errors[] = $lineNoError.$this->l('Shipping cost is required field');
                            } elseif (!Validate::isPrice($price)) {
                                $this->errors[] = $lineNoError.$this->l('Shipping cost should be valid');
                            }

                            if (empty($this->errors)) {
                                $shipRates[] = array(
                                    'distance_from' => $distanceFrom,
                                    'distance_to' => $distanceTo,
                                    'weight_from' => $weightFrom,
                                    'weight_to' => $weightTo,
                                    'price' => $price,
                                    'id_seller' => $idSeller
                                );
                            }

                            $lineNo++;
                        }

                        if (empty($this->errors)) {
                            if (!empty($shipRates)) {
                                foreach ($shipRates as $shipRate) {
                                    $objHyperlocalShipRate = new WkMpHyperlocalShipRate();
                                    $objHyperlocalShipRate->id_seller = $shipRate['id_seller'];
                                    $objHyperlocalShipRate->distance_from = $shipRate['distance_from'];
                                    $objHyperlocalShipRate->distance_to = $shipRate['distance_to'];
                                    $objHyperlocalShipRate->weight_from = $shipRate['weight_from'];
                                    $objHyperlocalShipRate->weight_to = $shipRate['weight_to'];
                                    $objHyperlocalShipRate->price = $shipRate['price'];
                                    $objHyperlocalShipRate->save();
                                }

                                Tools::redirectAdmin(self::$currentIndex.'&conf=3&token='.$this->token);
                            }
                        }
                    } else {
                        $this->errors[] = $this->l('Submitted CSV file is not valid. Please check the structure of CSV file by downloading demo file.');
                    }
                } else {
                    $this->errors[] = $this->l('File must contain valid extension (.csv).');
                }
            } else {
                $this->errors[] = $this->l('Please select a csv file.');
            }
        } else {
            $distanceFrom = trim(Tools::getValue('distance_from'));
            $distanceTo = trim(Tools::getValue('distance_to'));
            $weightFrom = trim(Tools::getValue('weight_from'));
            $weightTo = trim(Tools::getValue('weight_to'));

            if (empty($distanceFrom)) {
                $this->errors[] = $this->l('From distance is required field');
            } elseif (!Validate::isUnsignedFloat($distanceFrom)) {
                $this->errors[] = $this->l('value of from distance is not valid');
            }

            if (empty($distanceTo)) {
                $this->errors[] = $this->l('To distance is required field');
            } elseif (!Validate::isUnsignedFloat($distanceTo)) {
                $this->errors[] = $this->l('value of to distance is not valid');
            }

            if ($distanceFrom >= $distanceTo) {
                $this->errors[] = $this->l('From distance must be less than to distance');
            }

            if (empty($weightFrom)) {
                $this->errors[] = $this->l('From weight is required field');
            } elseif (!Validate::isUnsignedFloat($weightFrom)) {
                $this->errors[] = $this->l('value of from weight is not valid');
            }

            if (empty($weightTo)) {
                $this->errors[] = $this->l('To weight is required field');
            } elseif (!Validate::isUnsignedFloat($weightTo)) {
                $this->errors[] = $this->l('value of to weight is not valid');
            }

            if ($weightFrom >= $weightTo) {
                $this->errors[] = $this->l('From weight must be less than to weight');
            }

            if (empty($this->errors)) {
                return parent::processSave();
            } else {
                $this->display = 'add';
            }
        }
    }
}
