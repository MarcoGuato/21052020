<?php
/**
* 2010-2019 Webkul.
*
* NOTICE OF LICENSE
*
* All right is reserved,
* Please go through this link for complete license : https://store.webkul.com/license.html
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade this module to newer
* versions in the future. If you wish to customize this module for your
* needs please refer to https://store.webkul.com/customisation-guidelines/ for more information.
*
*  @author    Webkul IN <support@webkul.com>
*  @copyright 2010-2019 Webkul IN
*  @license   https://store.webkul.com/license.html
*/

class MpHyperlocalSystemMpSellerShipRateModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        parent::initContent();
        if (isset($this->context->customer->id)) {
            $mpSeller = WkMpSeller::getSellerDetailByCustomerId($this->context->customer->id);
            if ($mpSeller && $mpSeller['active']) {
                $idSeller = $mpSeller['id_seller'];
                if (Tools::getValue('addshiprate')) {
                    $this->context->smarty->assign('addshipingrate', true);
                } elseif ($id = Tools::getValue('id')) {
                    $objHlShipRate = new WkMpHyperlocalShipRate($id);
                    if (Validate::isLoadedObject($objHlShipRate) && $objHlShipRate->id_seller == $idSeller) {
                        if (Tools::getValue('deleteshiprate')) {
                            $objHlShipRate->delete();
                            Tools::redirect(
                                $this->context->link->getModuleLink(
                                    'mphyperlocalsystem',
                                    'mpsellershiprate',
                                    array('deleted_conf' => 1)
                                )
                            );
                        }

                        $this->context->smarty->assign('objHyperlcalShipRate', (array)$objHlShipRate);
                    } else {
                        Tools::redirect(
                            $this->context->link->getModuleLink('mphyperlocalsystem', 'managesellerhyperlocal')
                        );
                    }
                } else {
                    $sellerShipRate = WkMpHyperlocalShipRate::getSellerShipRate($idSeller);
                    if ($sellerShipRate) {
                        foreach ($sellerShipRate as &$data) {
                            $data['priceFormatted'] = Tools::displayPrice(Tools::convertPrice($data['price']));
                        }
                        $this->context->smarty->assign('sellerShipRate', $sellerShipRate);
                    }
                }

                WkMpHelper::assignGlobalVariables();
                //$objDefaultCurrency = new Currency(Configuration::get('PS_CURRENCY_DEFAULT'));
                $objDefaultCurrency = new Currency($this->context->currency->id);
                $objHlShipRate = new WkMpHyperlocalShipRate();
                $defaultPrice = $objHlShipRate->getDefaultPriceByIdSeller($idSeller);

                if ($defaultPrice) {
                    $this->context->smarty->assign(array(
                        'defaultShipRate' => Tools::displayPrice(Tools::convertPrice($defaultPrice['price'])),
                        'defaultShipRateWithoutSign' => $defaultPrice['price']
                    ));
                }
                $this->context->smarty->assign(array(
                    'is_seller' => $mpSeller['active'],
                    'logic' => 'ship_rate',
                    'defaultCurrencySign' => $objDefaultCurrency->sign,
                    'redius_unit' => Configuration::get('WK_MP_HYPERLOCAL_RADIUS_UNIT')
                ));

                $this->defineJSVars();
                $this->setTemplate('module:mphyperlocalsystem/views/templates/front/manageshiprate.tpl');
            } else {
                Tools::redirect($this->context->link->getModuleLink('marketplace', 'sellerrequest'));
            }
        } else {
            Tools::redirect($this->context->link->getPageLink('authentication'));
        }
    }

    public function getBreadcrumbLinks()
    {
        $breadCrumb = parent::getBreadcrumbLinks();
        $breadCrumb['links'][] = array(
            'title' => $this->module->l('Marketplace'),
            'url' => $this->context->link->getModuleLink('marketplace', 'dashboard')
        );

        $breadCrumb['links'][] = array(
            'title' => $this->module->l('Hyperlocal'),
            'url' => ''
        );
        return $breadCrumb;
    }


    public function postProcess()
    {
        $idCustomer = $this->context->customer->id;
        if (Tools::isSubmit('submitDefaultShiprate') && $idCustomer) {
            $seller = WkMpSeller::getSellerDetailByCustomerId($idCustomer);
            if ($seller && $seller['active']) {
                $defaultPrice = Tools::getValue('default_price');
                if ($defaultPrice == '') {
                    $this->errors[] = $this->module->l('Default price is required field');
                } elseif (!Validate::isPrice($defaultPrice)) {
                    $this->errors[] = $this->module->l('Default price be should be valid');
                }
                if (empty($this->errors)) {
                    $objHyperlcalShipRate = new WkMpHyperlocalShipRate();
                    $objHyperlcalShipRate->updateDefaultShipRate($seller['id_seller'], $defaultPrice);
                }
            }
        } elseif ((Tools::isSubmit('submitNewShipRate') || Tools::isSubmit('StayNewShipRate')) && $idCustomer) {
            $seller = WkMpSeller::getSellerDetailByCustomerId($idCustomer);
            if ($seller && $seller['active']) {
                $csv = Tools::getValue('csv');
                if ($csv) {
                    if ($_FILES['upload_csv']['size'] > 0) {
                        $extension = pathinfo($_FILES['upload_csv']['name'], PATHINFO_EXTENSION);
                        if ($extension == 'csv') {
                            $file = fopen((string) $_FILES['upload_csv']['tmp_name'], 'r');
                            $headerArray = fgetcsv($file);
                            $headerValidate = WkMpHyperlocalShipRate::validateCsvHeader($headerArray);
                            if ($headerValidate) {
                                $shipRates = array();
                                $lineNo = 2;
                                while (($result = fgetcsv($file)) !== false) {
                                    $distanceFrom = trim($result[0]);
                                    $distanceTo = trim($result[1]);
                                    $weightFrom = trim($result[2]);
                                    $weightTo = trim($result[3]);
                                    $price = trim($result[4]);
                                    $this->validateShipRateField(
                                        $distanceFrom,
                                        $distanceTo,
                                        $weightFrom,
                                        $weightTo,
                                        $price,
                                        $lineNo
                                    );
                                    if (empty($this->errors)) {
                                        $shipRates[] = array(
                                            'distance_from' => $distanceFrom,
                                            'distance_to' => $distanceTo,
                                            'weight_from' => $weightFrom,
                                            'weight_to' => $weightTo,
                                            'price' => $price
                                        );
                                    }

                                    $lineNo++;
                                }

                                if (empty($this->errors)) {
                                    if (!empty($shipRates)) {
                                        foreach ($shipRates as $shipRate) {
                                            $hlShipRate = new WkMpHyperlocalShipRate();
                                            $hlShipRate->id_seller = $seller['id_seller'];
                                            $hlShipRate->distance_from = $shipRate['distance_from'];
                                            $hlShipRate->distance_to = $shipRate['distance_to'];
                                            $hlShipRate->weight_from = $shipRate['weight_from'];
                                            $hlShipRate->weight_to = $shipRate['weight_to'];
                                            $hlShipRate->price = $shipRate['price'];
                                            $hlShipRate->save();
                                        }

                                        Tools::redirect(
                                            $this->context->link->getModuleLink(
                                                'mphyperlocalsystem',
                                                'mpsellershiprate',
                                                array('created_conf' => 1)
                                            )
                                        );
                                    }
                                }
                            } else {
                                $this->errors[] = $this->module->l('Submitted CSV file is not valid. Please check the structure of CSV file by downloading demo file.');
                            }
                        } else {
                            $this->errors[] = $this->module->l('File must contain valid extension (.csv).');
                        }
                    } else {
                        $this->errors[] = $this->module->l('Please select a csv file.');
                    }
                } else {
                    if ($id = Tools::getValue('id')) {
                        $hlShipRate = new WkMpHyperlocalShipRate($id);
                        if (!Validate::isLoadedObject($hlShipRate) && $hlShipRate->id_seller == $seller['id_seller']) {
                            Tools::redirect(
                                $this->context->link->getModuleLink('mphyperlocalsystem', 'mpsellershiprate')
                            );
                        }
                    }

                    $distanceFrom = trim(Tools::getValue('distance_from'));
                    $distanceTo = trim(Tools::getValue('distance_to'));
                    $weightFrom = trim(Tools::getValue('weight_from'));
                    $weightTo = trim(Tools::getValue('weight_to'));
                    $price = trim(Tools::getValue('price'));

                    $this->validateShipRateField($distanceFrom, $distanceTo, $weightFrom, $weightTo, $price);
                    if (empty($this->errors)) {
                        if (!isset($hlShipRate)) {
                            $hlShipRate = new WkMpHyperlocalShipRate();
                        }

                        $hlShipRate->id_seller = $seller['id_seller'];
                        $hlShipRate->distance_from = $distanceFrom;
                        $hlShipRate->distance_to = $distanceTo;
                        $hlShipRate->weight_from = $weightFrom;
                        $hlShipRate->weight_to = $weightTo;
                        $hlShipRate->price = $price;
                        $hlShipRate->save();
                        if (Tools::isSubmit('StayNewShipRate')) {
                            Tools::redirectAdmin(
                                $this->context->link->getModuleLink(
                                    'mphyperlocalsystem',
                                    'mpsellershiprate',
                                    array('created_conf' => 1, 'id' => $id)
                                )
                            );
                        } else {
                            Tools::redirectAdmin(
                                $this->context->link->getModuleLink(
                                    'mphyperlocalsystem',
                                    'mpsellershiprate',
                                    array('created_conf' => 1)
                                )
                            );
                        }
                    } else {
                        if (!$id) {
                            $this->context->smarty->assign('addshipingrate', true);
                        }
                    }
                }
            }
        }
    }

    private function validateShipRateField($distanceFrom, $distanceTo, $weightFrom, $weightTo, $price, $lineNo = false)
    {
        if ($lineNo) {
            $lineNoError = $this->module->l('Line number:') .' '. $lineNo .' '. $this->module->l('is having error').' ';
        } else {
            $lineNoError = '';
        }

        if ($distanceFrom == '') {
            $this->errors[] = $lineNoError.$this->module->l('Distance From is required field');
        } elseif (!Validate::isUnsignedFloat($distanceFrom)) {
            $this->errors[] = $lineNoError.$this->module->l('Distance From is not valid');
        }

        if ($distanceTo == '') {
            $this->errors[] = $lineNoError.$this->module->l('Distance To is required field');
        } elseif (!Validate::isUnsignedFloat($distanceTo)) {
            $this->errors[] = $lineNoError.$this->module->l('Distance To is not valid');
        }

        if ($distanceFrom >= $distanceTo) {
            $this->errors[] = $lineNoError.$this->module->l('Distance From must be less than to distance');
        }

        if ($weightFrom == '') {
            $this->errors[] = $lineNoError.$this->module->l('Weight From is required field');
        } elseif (!Validate::isUnsignedFloat($weightFrom)) {
            $this->errors[] = $lineNoError.$this->module->l('Weight From is not valid');
        }

        if ($weightTo == '') {
            $this->errors[] = $lineNoError.$this->module->l('Weight To is required field');
        } elseif (!Validate::isUnsignedFloat($weightTo)) {
            $this->errors[] = $lineNoError.$this->module->l('Weight To is not valid');
        }

        if ($weightFrom >= $weightTo) {
            $this->errors[] = $lineNoError.$this->module->l('Weight From must be less than to weight');
        }

        if ($price == '') {
            $this->errors[] = $lineNoError.$this->module->l('Shipping cost is required field');
        } elseif (!Validate::isPrice($price)) {
            $this->errors[] = $lineNoError.$this->module->l('Shipping cost should be valid');
        }
    }

    public function defineJSVars()
    {
        $jsVars = array(
            'confirm_msg' => $this->module->l('Are you sure?', 'mpsellershiprate'),
            'wk_dataTables' => 1,
            'display_name' => $this->module->l('Display', 'mpsellershiprate'),
            'records_name' => $this->module->l('records per page', 'mpsellershiprate'),
            'no_product' => $this->module->l('No ship rate found', 'mpsellershiprate'),
            'show_page' => $this->module->l('Showing page', 'mpsellershiprate'),
            'show_of' => $this->module->l('of', 'mpsellershiprate'),
            'no_record' => $this->module->l('No records mpsellershiprate', 'mpsellershiprate'),
            'filter_from' => $this->module->l('filtered from', 'mpsellershiprate'),
            't_record' => $this->module->l('total records', 'mpsellershiprate'),
            'search_item' => $this->module->l('Search', 'mpsellershiprate'),
            'p_page' => $this->module->l('Previous', 'mpsellershiprate'),
            'n_page' => $this->module->l('Next', 'mpsellershiprate'),
        );

        Media::addJsDef($jsVars);
    }

    public function setMedia()
    {
        parent::setMedia();

        $this->registerStylesheet('marketplace_account', 'modules/marketplace/views/css/marketplace_account.css');
        $this->registerStylesheet(
            'mpsellerhyperlocalcss',
            'modules/'.$this->module->name.'/views/css/mpsellerhyperlocal.css'
        );
        $this->registerJavascript(
            'mpsellerhyperlocaljs',
            'modules/'.$this->module->name.'/views/js/mpsellerhyperlocal.js'
        );

        //data table file included
        $this->registerStylesheet('datatable_bootstrap', 'modules/marketplace/views/css/datatable_bootstrap.css');
        $this->registerJavascript('mp-jquery-dataTables', 'modules/marketplace/views/js/jquery.dataTables.min.js');
        $this->registerJavascript('mp-dataTables.bootstrap', 'modules/marketplace/views/js/dataTables.bootstrap.js');

        //If admin allow to use custom css on Marketplace theme
        if (Configuration::get('WK_MP_ALLOW_CUSTOM_CSS')) {
            $this->registerStylesheet('mp-custom_style-css', 'modules/marketplace/views/css/mp_custom_style.css');
        }
    }
}
