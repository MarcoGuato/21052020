<?php
/**
* 2010-2019 Webkul.
*
* NOTICE OF LICENSE
*
* All right is reserved,
* Please go through this link for complete license : https://store.webkul.com/license.html
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade this module to newer
* versions in the future. If you wish to customize this module for your
* needs please refer to https://store.webkul.com/customisation-guidelines/ for more information.
*
*  @author    Webkul IN <support@webkul.com>
*  @copyright 2010-2019 Webkul IN
*  @license   https://store.webkul.com/license.html
*/

class MpHyperlocalSystemManageSellerHyperlocalModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        parent::initContent();
        if (isset($this->context->customer->id)) {
            $mpSeller = WkMpSeller::getSellerDetailByCustomerId($this->context->customer->id);
            if ($mpSeller && $mpSeller['active']) {
                $idSeller = $mpSeller['id_seller'];
                $sellerShipArea = WkMpHyperlocalShipArea::getSellerShipArea($idSeller);

                if ($sellerShipArea) {
                    $this->context->smarty->assign('sellerShipArea', $sellerShipArea);
                }

                WkMpHelper::assignGlobalVariables();

                $this->context->smarty->assign(array(
                    'is_seller' => $mpSeller['active'],
                    'logic' => 'ship_area',
                ));

                $this->defineJSVars();
                $this->setTemplate('module:mphyperlocalsystem/views/templates/front/manageshiparea.tpl');
            } else {
                Tools::redirect($this->context->link->getModuleLink('marketplace', 'sellerrequest'));
            }
        } else {
            Tools::redirect($this->context->link->getPageLink('authentication'));
        }
    }

    public function getBreadcrumbLinks()
    {
        $breadCrumb = parent::getBreadcrumbLinks();
        $breadCrumb['links'][] = array(
            'title' => $this->module->l('Marketplace'),
            'url' => $this->context->link->getModuleLink('marketplace', 'dashboard')
        );

        $breadCrumb['links'][] = array(
            'title' => $this->module->l('Hyperlocal'),
            'url' => ''
        );
        return $breadCrumb;
    }

    public function defineJSVars()
    {
        $jsVars = array(
            'confirm_msg' => $this->module->l('Are you sure?', 'managesellerhyperlocal'),
            'wk_dataTables' => 1,
            'display_name' => $this->module->l('Display', 'managesellerhyperlocal'),
            'records_name' => $this->module->l('records per page', 'managesellerhyperlocal'),
            'no_product' => $this->module->l('No shipping area found', 'managesellerhyperlocal'),
            'show_page' => $this->module->l('Showing page', 'managesellerhyperlocal'),
            'show_of' => $this->module->l('of', 'managesellerhyperlocal'),
            'no_record' => $this->module->l('No records managesellerhyperlocal', 'managesellerhyperlocal'),
            'filter_from' => $this->module->l('filtered from', 'managesellerhyperlocal'),
            't_record' => $this->module->l('total records', 'managesellerhyperlocal'),
            'search_item' => $this->module->l('Search', 'managesellerhyperlocal'),
            'p_page' => $this->module->l('Previous', 'managesellerhyperlocal'),
            'n_page' => $this->module->l('Next', 'managesellerhyperlocal'),
        );

        Media::addJsDef($jsVars);
    }

    public function setMedia()
    {
        parent::setMedia();

        $this->registerStylesheet('marketplace_account', 'modules/marketplace/views/css/marketplace_account.css');
        $this->registerStylesheet(
            'mpsellerhyperlocalcss',
            'modules/'.$this->module->name.'/views/css/mpsellerhyperlocal.css'
        );
        $this->registerJavascript(
            'mpsellerhyperlocaljs',
            'modules/'.$this->module->name.'/views/js/mpsellerhyperlocal.js'
        );

        //data table file included
        $this->registerStylesheet('datatable_bootstrap', 'modules/marketplace/views/css/datatable_bootstrap.css');
        $this->registerJavascript('mp-jquery-dataTables', 'modules/marketplace/views/js/jquery.dataTables.min.js');
        $this->registerJavascript('mp-dataTables.bootstrap', 'modules/marketplace/views/js/dataTables.bootstrap.js');

        //If admin allow to use custom css on Marketplace theme
        if (Configuration::get('WK_MP_ALLOW_CUSTOM_CSS')) {
            $this->registerStylesheet('mp-custom_style-css', 'modules/marketplace/views/css/mp_custom_style.css');
        }
    }
}
