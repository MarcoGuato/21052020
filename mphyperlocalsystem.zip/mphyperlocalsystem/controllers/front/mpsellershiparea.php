<?php
/**
* 2010-2019 Webkul.
*
* NOTICE OF LICENSE
*
* All right is reserved,
* Please go through this link for complete license : https://store.webkul.com/license.html
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade this module to newer
* versions in the future. If you wish to customize this module for your
* needs please refer to https://store.webkul.com/customisation-guidelines/ for more information.
*
*  @author    Webkul IN <support@webkul.com>
*  @copyright 2010-2019 Webkul IN
*  @license   https://store.webkul.com/license.html
*/

class MpHyperlocalSystemMpSellerShipAreaModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        parent::initContent();
        $link = new Link();
        if (isset($this->context->customer->id)) {
            $mpSeller = WkMpSeller::getSellerDetailByCustomerId($this->context->customer->id);
            if ($mpSeller && $mpSeller['active']) {
                $idSeller = $mpSeller['id_seller'];
                if ($id = Tools::getValue('id')) {
                    $hlShipArea = new WkMpHyperlocalShipArea($id);
                    if (Validate::isLoadedObject($hlShipArea) && $hlShipArea->id_seller == $idSeller) {
                        if (Tools::getValue('deleteshiparea')) {
                            $hlShipArea->delete();
                            Tools::redirect(
                                $this->context->link->getModuleLink(
                                    'mphyperlocalsystem',
                                    'managesellerhyperlocal',
                                    array('deleted_conf' => 1)
                                )
                            );
                        }

                        $this->context->smarty->assign('objHyperlcalShipArea', (array)$hlShipArea);
                    } else {
                        Tools::redirect(
                            $link->getModuleLink('mphyperlocalsystem', 'managesellerhyperlocal')
                        );
                    }
                }

                WkMpHelper::assignGlobalVariables();

                $this->context->smarty->assign(array(
                    'is_seller' => $mpSeller['active'],
                    'logic' => 'ship_area',
                ));

                $this->setTemplate('module:mphyperlocalsystem/views/templates/front/addshiparea.tpl');
            } else {
                Tools::redirect($link->getModuleLink('marketplace', 'sellerrequest'));
            }
        } else {
            Tools::redirect($link->getPageLink('authentication'));
        }
    }

    public function getBreadcrumbLinks()
    {
        $breadCrumb = parent::getBreadcrumbLinks();
        $breadCrumb['links'][] = array(
            'title' => $this->module->l('Marketplace'),
            'url' => $this->context->link->getModuleLink('marketplace', 'dashboard')
        );

        $breadCrumb['links'][] = array(
            'title' => $this->module->l('Hyperlocal'),
            'url' => ''
        );
        return $breadCrumb;
    }


    public function postProcess()
    {
        if (Tools::isSubmit('submitShipArea') && $this->context->customer->id) {
            $seller = WkMpSeller::getSellerDetailByCustomerId($this->context->customer->id);
            if ($seller && $seller['active']) {
                $idSeller = $seller['id_seller'];
                if ($id = Tools::getValue('id')) {
                    $hlShipArea = new WkMpHyperlocalShipArea($id);
                    if (!Validate::isLoadedObject($hlShipArea) && $hlShipArea->id_seller == $idSeller) {
                        Tools::redirect(
                            $this->context->link->getModuleLink('mphyperlocalsystem', 'managesellerhyperlocal')
                        );
                    }
                }

                $address = Tools::getValue('address');
                $latitude = Tools::getValue('latitude');
                $longitude = Tools::getValue('longitude');

                if (empty($address)) {
                    $this->errors[] = $this->module->l('Address is required field');
                }

                if (empty($latitude)) {
                    $this->errors[] = $this->module->l('Latitude is required field');
                }

                if (empty($longitude)) {
                    $this->errors[] = $this->module->l('Longitude is required field');
                }

                if (empty($this->errors)) {
                    if (!isset($hlShipArea)) {
                        $hlShipArea = new WkMpHyperlocalShipArea();
                    }

                    $hlShipArea->id_seller = $idSeller;
                    $hlShipArea->address = $address;
                    $hlShipArea->latitude = preg_replace('/\.(\d{6}).*/', '.$1', $latitude);
                    $hlShipArea->longitude = preg_replace('/\.(\d{6}).*/', '.$1', $longitude);

                    if (!Configuration::get('WK_MP_SHIP_AREA_ADMIN_APPROVE')) {
                        $hlShipArea->active = true;
                    } else {
                        $hlShipArea->active = false;
                    }

                    $hlShipArea->save();
                    Tools::redirect(
                        $this->context->link->getModuleLink(
                            'mphyperlocalsystem',
                            'managesellerhyperlocal',
                            array('created_conf' => 1)
                        )
                    );
                }
            }
        }
    }

    public function setMedia()
    {
        parent::setMedia();

        $language = $this->context->language;
        $country = $this->context->country;
        $mpGoogleApiKey = Configuration::get('WK_MP_GOOGLE_API_KEY');

        $this->registerJavascript(
            'google-map-lib',
            "https://maps.googleapis.com/maps/api/js?key=$mpGoogleApiKey&libraries=places&language=$language->iso_code&region=$country->iso_code&region=$country->iso_code&v=3.31",
            array('server' => 'remote')
        );

        $this->registerJavascript('locationsearchJs', 'modules/'.$this->module->name.'/views/js/locationsearch.js');

        $this->registerStylesheet('marketplace_account', 'modules/marketplace/views/css/marketplace_account.css');
        $this->registerStylesheet(
            'mpsellerhyperlocalcss',
            'modules/'.$this->module->name.'/views/css/mpsellerhyperlocal.css'
        );
        $this->registerJavascript(
            'mpsellerhyperlocaljs',
            'modules/'.$this->module->name.'/views/js/mpsellerhyperlocal.js'
        );

        //data table file included
        $this->registerStylesheet('datatable_bootstrap', 'modules/marketplace/views/css/datatable_bootstrap.css');
        $this->registerJavascript('mp-jquery-dataTables', 'modules/marketplace/views/js/jquery.dataTables.min.js');
        $this->registerJavascript('mp-dataTables.bootstrap', 'modules/marketplace/views/js/dataTables.bootstrap.js');

        //If admin allow to use custom css on Marketplace theme
        if (Configuration::get('WK_MP_ALLOW_CUSTOM_CSS')) {
            $this->registerStylesheet('mp-custom_style-css', 'modules/marketplace/views/css/mp_custom_style.css');
        }
    }
}
