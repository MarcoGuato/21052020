<?php
/**
* 2010-2019 Webkul.
*
* NOTICE OF LICENSE
*
* All right is reserved,
* Please go through this link for complete license : https://store.webkul.com/license.html
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade this module to newer
* versions in the future. If you wish to customize this module for your
* needs please refer to https://store.webkul.com/customisation-guidelines/ for more information.
*
*  @author    Webkul IN <support@webkul.com>
*  @copyright 2010-2019 Webkul IN
*  @license   https://store.webkul.com/license.html
*/

class MpHyperlocalSystemMpSetCustomerLocationModuleFrontController extends ModuleFrontController
{
    public function init()
    {
        parent::init();
        $this->display_header = false;
        $this->display_footer = false;
    }

    public function initContent()
    {
        $address = Tools::getValue('address');
        $latitude = Tools::getValue('latitude');
        $longitude = Tools::getValue('longitude');
        $addressArray = Tools::getValue('addressArray');
        if ($address && $latitude && $longitude) {
            $cookie = new Cookie('wkhyperlocal_cookie');
            $cookie->wkHyperlocalAddress = $address;
            $cookie->wkHyperlocalLatitude = $latitude;
            $cookie->wkHyperlocalLongitude = $longitude;
            $cookie->wkHyperAddresComponent = $addressArray;
            $cookie->write();
            $objCart = $this->context->cart;
            $cartProducts = $objCart->getProducts();
            foreach ($cartProducts as $product) {
                $objCart->deleteProduct(
                    $product['id_product'],
                    $product['id_product_attribute'],
                    $product['id_customization'],
                    $product['id_address_delivery']
                );
            }

            die(Tools::jsonEncode(array('status' => 'ok')));
        } else {
            die(Tools::jsonEncode(array('status' => 'failed', 'message' => $this->module->l('Fill correct address'))));
        }
    }
}
