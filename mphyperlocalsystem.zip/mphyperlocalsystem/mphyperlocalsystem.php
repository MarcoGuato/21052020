<?php
/**
* 2010-2019 Webkul.
*
* NOTICE OF LICENSE
*
* All right is reserved,
* Please go through this link for complete license : https://store.webkul.com/license.html
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade this module to newer
* versions in the future. If you wish to customize this module for your
* needs please refer to https://store.webkul.com/customisation-guidelines/ for more information.
*
*  @author    Webkul IN <support@webkul.com>
*  @copyright 2010-2019 Webkul IN
*  @license   https://store.webkul.com/license.html
*/

if (!defined('_PS_VERSION_')) {
    exit;
}

include_once dirname(__FILE__).'/../marketplace/classes/WkMpRequiredClasses.php';
include_once 'classes/MpHyperlocalSystemDb.php';
include_once 'classes/WkMpHyperlocalShipArea.php';
include_once 'classes/WkMpHyperlocalShipRate.php';

class MpHyperlocalSystem extends CarrierModule
{
    private $html = '';
    private $postErrors = array();
    public $id_carrier;
    public function __construct()
    {
        $this->name = 'mphyperlocalsystem';
        $this->tab = 'front_office_features';
        $this->version = '5.0.2';
        $this->author = 'Webkul';
        $this->need_instance = 1;
        $this->ps_versions_compliancy = array('min' => '1.7', 'max' => _PS_VERSION_);
        $this->bootstrap = true;
        $this->dependencies = array('marketplace');
        parent::__construct();
        $this->displayName = $this->l('Marketplace Hyperlocal System');
        $this->description = $this->l('Hyperlocal System connects the customers with local stores and also transforming the shopping experience of the customers');
    }

    private function postProcess()
    {
        if (Tools::isSubmit('btnSubmit')) {
            Configuration::updateValue('WK_MP_GOOGLE_API_KEY', Tools::getValue('WK_MP_GOOGLE_API_KEY'));
            Configuration::updateValue('WK_MP_HYPERLOCAL_RADIUS_UNIT', Tools::getValue('WK_MP_HYPERLOCAL_RADIUS_UNIT'));
            Configuration::updateValue('WK_MP_HYPERLOCAL_DISTANCE', Tools::getValue('WK_MP_HYPERLOCAL_DISTANCE'));
            Configuration::updateValue(
                'WK_MP_SHIP_AREA_ADMIN_APPROVE',
                Tools::getValue('WK_MP_SHIP_AREA_ADMIN_APPROVE')
            );
            Configuration::updateValue(
                'WK_MP_HYPERLOCAL_OUT_OF_RANGE',
                Tools::getValue('WK_MP_HYPERLOCAL_OUT_OF_RANGE')
            );
            Configuration::updateValue(
                'WK_MP_HYPERLOCAL_OUT_OF_RANGE',
                Tools::getValue('WK_MP_HYPERLOCAL_OUT_OF_RANGE')
            );
            if (Configuration::get('WK_MP_HYPERLOCAL_OUT_OF_RANGE') == 1) {
                Configuration::updateValue(
                    'WK_MP_HYPERLOCAL_OUT_OF_RANGE_PRICE',
                    Tools::getValue('WK_MP_HYPERLOCAL_OUT_OF_RANGE_PRICE')
                );
            } else {
                Configuration::updateValue('WK_MP_HYPERLOCAL_OUT_OF_RANGE_PRICE', '');
            }
        }

        $this->html .= $this->displayConfirmation($this->l('Settings updated'));
    }

    private function postValidation()
    {
        if (Tools::isSubmit('btnSubmit')) {
            if (Tools::getValue('WK_MP_GOOGLE_API_KEY') == '') {
                $this->postErrors[] = $this->l('Google API KEY is required field');
            } elseif (Tools::getValue('WK_MP_HYPERLOCAL_DISTANCE') == '') {
                $this->postErrors[] = $this->l('Distance field is required field');
            } elseif (!Validate::isUnsignedInt(Tools::getValue('WK_MP_HYPERLOCAL_DISTANCE'))) {
                $this->postErrors[] = $this->l('Distance field should be valid');
            }
            if (Tools::getValue('WK_MP_HYPERLOCAL_OUT_OF_RANGE') == 1) {
                if (Tools::getValue('WK_MP_HYPERLOCAL_OUT_OF_RANGE_PRICE') == '') {
                    $this->postErrors[] = $this->l('Default price is required field');
                } elseif (!Validate::isPrice(Tools::getValue('WK_MP_HYPERLOCAL_OUT_OF_RANGE_PRICE'))) {
                    $this->postErrors[] = $this->l('Default price is not valid.');
                }
            }
        }
    }

    public function getContent()
    {
        $this->context->controller->addJs($this->_path.'views/js/configuration.js');
        if (Tools::isSubmit('btnSubmit')) {
            $this->postValidation();
            if (!count($this->postErrors)) {
                $this->postProcess();
            } else {
                foreach ($this->postErrors as $err) {
                    $this->html .= $this->displayError($err);
                }
            }
        } else {
            $this->html .= '<br />';
        }
        $this->html .= $this->renderForm();

        return $this->html;
    }

    public function renderForm()
    {
        $fields_form = array(
            'form' => array(
                'legend' => array(
                    'title' => $this->l('Configuration'),
                    'icon' => 'icon-cogs',
                ),
                'input' => array(
                    array(
                        'type' => 'text',
                        'label' => $this->l('Google API Key'),
                        'name' => 'WK_MP_GOOGLE_API_KEY',
                        'required' => true,
                        'hint' => $this->l('Unique API key for geolocation google map'),
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Radius Unit'),
                        'name' => 'WK_MP_HYPERLOCAL_RADIUS_UNIT',
                        'options' => array(
                            'query' => array(
                                array('key' => '1', 'name' => $this->l('Mile')),
                                array('key' => '2', 'name' => $this->l('Kilometer')),
                            ),
                            'id' => 'key',
                            'name' => 'name'
                        ),
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Distance (Radius)'),
                        'name' => 'WK_MP_HYPERLOCAL_DISTANCE',
                        'col' => 3,
                        'required' => true,
                        'hint' => $this->l('Distance for location'),
                    ),
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Shipping area needs to be approved by admin'),
                        'name' => 'WK_MP_SHIP_AREA_ADMIN_APPROVE',
                        'col' => 3,
                        'required' => false,
                        'is_bool' => true,
                        'values' => array(
                            array(
                                'id' => 'active_on',
                                'value' => 1,
                                'label' => $this->l('Yes'),
                            ),
                            array(
                                'id' => 'active_off',
                                'value' => 0,
                                'label' => $this->l('No'),
                            ),
                        ),
                        'hint' => $this->l('If No, Seller shipping area gets approved automatically.'),
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Out-of-range behavior'),
                        'name' => 'WK_MP_HYPERLOCAL_OUT_OF_RANGE',
                        'options' => array(
                            'query' => array(
                                array('key' => '1', 'name' => $this->l('Set default price')),
                                array('key' => '2', 'name' => $this->l('Disable carrier')),
                            ),
                            'id' => 'key',
                            'name' => 'name'
                        ),
                        'hint' => $this->l('Out-of-range behavior occurs when no defined range matches the customer\'s cart (e.g. when the distance and weight of the cart is not defined by ship rate range ).'),
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Default shipping price'),
                        'col' => 3,
                        'required' => true,
                        'suffix' => $this->context->currency->getSign(),
                        'class' => 'wk-default-price',
                        'name' => 'WK_MP_HYPERLOCAL_OUT_OF_RANGE_PRICE',
                        'hint' => $this->l('If Out-of-range behavior behavior is selected as \'default price\', than set default shipping price.'),
                    ),
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                ),
            ),
        );

        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $lang = new Language((int) Configuration::get('PS_LANG_DEFAULT'));
        $helper->default_form_language = $lang->id;
        $this->fields_form = array();
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'btnSubmit';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFieldsValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        );

        return $helper->generateForm(array($fields_form));
    }

    public function getConfigFieldsValues()
    {
        return array(
            'WK_MP_GOOGLE_API_KEY' => Tools::getValue(
                'WK_MP_GOOGLE_API_KEY',
                Configuration::get('WK_MP_GOOGLE_API_KEY')
            ),
            'WK_MP_HYPERLOCAL_RADIUS_UNIT' => Tools::getValue(
                'WK_MP_HYPERLOCAL_RADIUS_UNIT',
                Configuration::get('WK_MP_HYPERLOCAL_RADIUS_UNIT')
            ),
            'WK_MP_HYPERLOCAL_DISTANCE' => Tools::getValue(
                'WK_MP_HYPERLOCAL_DISTANCE',
                Configuration::get('WK_MP_HYPERLOCAL_DISTANCE')
            ),
            'WK_MP_SHIP_AREA_ADMIN_APPROVE' => Tools::getValue(
                'WK_MP_SHIP_AREA_ADMIN_APPROVE',
                Configuration::get('WK_MP_SHIP_AREA_ADMIN_APPROVE')
            ),
            'WK_MP_HYPERLOCAL_OUT_OF_RANGE' => Tools::getValue(
                'WK_MP_HYPERLOCAL_OUT_OF_RANGE',
                Configuration::get('WK_MP_HYPERLOCAL_OUT_OF_RANGE')
            ),
            'WK_MP_HYPERLOCAL_OUT_OF_RANGE_PRICE' => Tools::getValue(
                'WK_MP_HYPERLOCAL_OUT_OF_RANGE_PRICE',
                Configuration::get('WK_MP_HYPERLOCAL_OUT_OF_RANGE_PRICE')
            ),
        );
    }

    /**
     * Calling ps core abstract function
     * @param  object $cart
     * @param  float $shippingCost
     * @param  array $products
     * @return false/float shipping_cost
    */
    public function getPackageShippingCost($cart, $shippingCost, $products)
    {
        if (Tools::getIsset('controller')) {
            $controller = Tools::getValue('controller');
            if ($controller != 'cart'
                && $controller != 'index'
                && $controller != 'category'
                && $controller != 'product'
            ) {
                if (Configuration::get('WK_MP_HYPERLOCAL_CARRIER_ID') == $this->id_carrier) {
                    if ($cart->id_address_delivery) {
                        $address = $this->getFormateAddress($cart->id_address_delivery);
                        $sellerWiseWeight = $this->getSellerTotalWeight($products);
                        $objShipArea = new WkMpHyperlocalShipArea();
                        return $objShipArea->checkCustomerDistanceByAddress($address, $sellerWiseWeight);
                    }
                }
            }
        }

        return false;
    }

    public function getOrderShippingCost($cart, $shippingCost)
    {
        //Seller Of Product Tree Art Not Provide Shipping Service At Your Location.
        if (Tools::getIsset('controller')) {
            $controller = Tools::getValue('controller');
            if ($controller != 'cart'
                && $controller != 'index'
                && $controller != 'category'
                && $controller != 'product'
            ) {
                if (Configuration::get('WK_MP_HYPERLOCAL_CARRIER_ID') == $this->id_carrier) {
                    if ($cart->id_address_delivery) {
                        $address = $this->getFormateAddress($cart->id_address_delivery);
                        $sellerWiseWeight = $this->getSellerTotalWeight($cart->getProducts());
                        $objShipArea = new WkMpHyperlocalShipArea();
                        return $objShipArea->checkCustomerDistanceByAddress($address, $sellerWiseWeight);
                    }
                }
            }
        }

        return false;
    }

    private function getSellerTotalWeight($products)
    {
        $sellerWiseWeight = array();
        foreach ($products as $product) {
            $sellerProduct = WkMpSellerProduct::getSellerProductByPsIdProduct($product['id_product']);
            $weight = 0;

            if (!isset($product['weight_attribute']) || is_null($product['weight_attribute'])) {
                $weight = $product['weight'] * $product['cart_quantity'];
            } else {
                $weight = $product['weight_attribute'] * $product['cart_quantity'];
            }

            if ($sellerProduct) {
                if (isset($sellerWiseWeight[$sellerProduct['id_seller']])) {
                    $sellerWiseWeight[$sellerProduct['id_seller']] += $weight;
                } else {
                    $sellerWiseWeight[$sellerProduct['id_seller']] = $weight;
                }
            } else {
                if (isset($sellerWiseWeight[0])) {
                    $sellerWiseWeight[0] += $weight;
                } else {
                    $sellerWiseWeight[0] = $weight;
                }
            }
        }

        return $sellerWiseWeight;
    }

    private function getFormateAddress($idAddress)
    {
        $objaddress = new Address($idAddress);
        return AddressFormat::generateAddress(
            $objaddress,
            array('avoid' => array('firstname', 'lastname', 'vat_number', 'phone', 'company')),
            ' '
        );
    }

    /**
     * Calling abstract function for shipping price
     */
    public function getOrderShippingCostExternal($params)
    {
        $this->getOrderShippingCost($params, 0);
    }

    /**
     * Distribute when mpshipping install
     * @return false/array shipping_cost
     */
    public function hookActionShippingDistributionCost($params)
    {
        $cart = $params['cart'];
        $sellerSplitDetail = $params['seller_splitDetail'];
        $carrierList = array();
        $sellerWiseWeight = array();
        $distributorShippingCost = array();
        //May be same cart has one or more carrier, So we get all carriers for split before order
        $cartDeliveryList = $cart->getDeliveryOptionList();
        if ($cartDeliveryList) {
            foreach ($cartDeliveryList as $cartDeliveryOption) {
                if ($cartDeliveryOption) {
                    foreach ($cartDeliveryOption as $carrierListData) {
                        if ($carrierListData) {
                            $carrierList = $carrierListData['carrier_list'];
                        }
                    }
                }
            }
        }

        if (count($carrierList) == 1 && isset($carrierList[Configuration::get('WK_MP_HYPERLOCAL_CARRIER_ID')])) {
            if ($sellerSplitDetail) {
                foreach ($sellerSplitDetail as $idSellerCustomer => $product) {
                    if ($idSellerCustomer == 'admin') {
                        $sellerWiseWeight[0] = $product['total_product_weight'];
                    } else {
                        $sellerWiseWeight[$idSellerCustomer] = $product['total_product_weight'];
                    }
                }

                $address = $this->getFormateAddress($cart->id_address_delivery);
                $objShipArea = new WkMpHyperlocalShipArea();
                return $objShipArea->getSellerWiseHyperlocalCost($address, $sellerWiseWeight);
            }
        } elseif (count($carrierList) > 1 && isset($carrierList[Configuration::get('WK_MP_HYPERLOCAL_CARRIER_ID')])) {
            $adminCost = 0;
            foreach ($carrierList as $idCarrier => $carrierData) {
                //All Carriers distribution (one by one) will be divide b/w sellers and admin
                $totalShippingCost = $cart->getOrderShippingCost($idCarrier);
                if ($idCarrier == Configuration::get('WK_MP_HYPERLOCAL_CARRIER_ID')) {
                    if (isset($carrierData['product_list'])) {
                        foreach ($carrierData['product_list'] as $product) {
                            //Check if product is seller product
                            if (!isset($product['weight_attribute']) || is_null($product['weight_attribute'])) {
                                $weight = $product['weight'] * $product['cart_quantity'];
                            } else {
                                $weight = $product['weight_attribute'] * $product['cart_quantity'];
                            }

                            if ($sellerProduct = WkMpSellerProduct::getSellerProductByPsIdProduct($product['id_product'])) {
                                //Get seller customer id of seller product
                                $sellerDetails = WkMpSeller::getSeller($sellerProduct['id_seller']);
                                if (isset($sellerWiseWeight[$sellerDetails['seller_customer_id']])) {
                                    $sellerWiseWeight[$sellerDetails['seller_customer_id']] += $weight;
                                } else {
                                    $sellerWiseWeight[$sellerDetails['seller_customer_id']] = $weight;
                                }
                            } else {
                                if (isset($sellerWiseWeight[0])) {
                                    $sellerWiseWeight[0] += $weight;
                                } else {
                                    $sellerWiseWeight[0] = $weight;
                                }
                            }
                        }

                        $address = $this->getFormateAddress($cart->id_address_delivery);
                        $objShipArea = new WkMpHyperlocalShipArea();
                        $hyperlocalCost = $objShipArea->getSellerWiseHyperlocalCost($address, $sellerWiseWeight);
                    }
                } else {
                    $adminCost += $totalShippingCost;
                }
            }

            if (isset($hyperlocalCost['admin'])) {
                $hyperlocalCost['admin'] += $adminCost;
            } else {
                $hyperlocalCost['admin'] = $adminCost;
            }

            return $hyperlocalCost;
        }

        return false;
    }

    /**
     * Update shipping cost in marketplace transation history
     * @return false/float shipping_cost
     */
    public function hookActionShippingDistribution($params)
    {
        $order = $params['order'];
        $sellerSplitDetail = $params['seller_splitDetail'];
        if (($order->id_carrier == Configuration::get('WK_MP_HYPERLOCAL_CARRIER_ID'))) {
            $sellerWiseWeight  = array();
            foreach ($sellerSplitDetail as $idSellerCustomer => $product) {
                if ($idSellerCustomer == 'admin') {
                    $sellerWiseWeight[0] = $product['total_product_weight'];
                } else {
                    $sellerWiseWeight[$idSellerCustomer] = $product['total_product_weight'];
                }
            }

            $address = $this->getFormateAddress($order->id_address_delivery);
            $objShipArea = new WkMpHyperlocalShipArea();
            return $objShipArea->getSellerWiseHyperlocalCost($address, $sellerWiseWeight);
        }

        return false;
    }

    /**
     * If direct product link open, redirect to index page
     */
    public function hookDisplayProductButtons($params)
    {
        $idProduct = $params['product']['id_product'];
        $mpProductDeatail = WkMpSellerProduct::getSellerProductByPsIdProduct($idProduct);
        if ($mpProductDeatail) {
            $idSeller = $mpProductDeatail['id_seller'];
        } else {
            $idSeller = 0;
        }

        $cookie = new Cookie('wkhyperlocal_cookie');
        if (isset($cookie->wkHyperlocalLatitude) && isset($cookie->wkHyperlocalLongitude)) {
            $objhyperlocalShipArea = new WkMpHyperlocalShipArea();
            $shipAreaSeller = $objhyperlocalShipArea->calculateMinimumDistaceByCustomerAddress(
                $cookie->wkHyperlocalLatitude,
                $cookie->wkHyperlocalLongitude,
                $idSeller
            );

            if ($shipAreaSeller === false) {
                Tools::redirect($this->context->link->getPageLink('index', true));
            }
        }
    }

    public function hookDisplayMpmyaccountmenu($params)
    {
        $idCustomer = $this->context->customer->id;
        if ($idCustomer) {
            $mpSeller = WkMpSeller::getSellerDetailByCustomerId($idCustomer);
            if ($mpSeller && $mpSeller['active']) {
                $this->context->smarty->assign('mpmenu', '0');
                return $this->fetch('module:mphyperlocalsystem/views/templates/hook/hyperlocal_link.tpl');
            }
        }
    }

    public function hookDisplayMPMenuBottom($params)
    {
        $idCustomer = $this->context->customer->id;
        if ($idCustomer) {
            $mpSeller = WkMpSeller::getSellerDetailByCustomerId($idCustomer);
            if ($mpSeller && $mpSeller['active']) {
                $this->context->smarty->assign('mpmenu', '1');
                return $this->fetch('module:mphyperlocalsystem/views/templates/hook/hyperlocal_link.tpl');
            }
        }
    }

    /**
     * Display Sell on link on navigation bar.
     *
     * @return html An link with text Sell on shop name
     */
    public function hookDisplayNav1()
    {
        if (Tools::getIsset('controller')) {
            $controller = Tools::getValue('controller');
            if ($controller != 'order') {
                $cookie = new Cookie('wkhyperlocal_cookie');
                if (!isset($cookie->wkHyperlocalAddress)) {
                    return $this->fetch('module:mphyperlocalsystem/views/templates/hook/setlocation.tpl');
                }
            }
        }
    }

    /**
     * Display location select popup form
     */
    public function hookDisplayHeader()
    {
        if (Tools::getIsset('controller')) {
            $controller = Tools::getValue('controller');
            if ($controller != 'order') {
                $cookie = new Cookie('wkhyperlocal_cookie');
                if (isset($cookie->wkHyperlocalAddress)) {
                    $shipAreaSeller = WkMpHyperlocalShipArea::calculateShipAreaDistance(
                        $cookie->wkHyperlocalLatitude,
                        $cookie->wkHyperlocalLongitude
                    );
                    $this->context->smarty->assign(array(
                        'wkaddress' => $cookie->wkHyperlocalAddress,
                        'wklatitude' => $cookie->wkHyperlocalLatitude,
                        'wklongitude' => $cookie->wkHyperlocalLongitude,
                    ));
                    return $this->fetch('module:mphyperlocalsystem/views/templates/hook/setlocation.tpl');
                }
            }
        }
    }

    /**
     * Delete seller data when seller delete
     */
    public function hookActionMpSellerDelete($params)
    {
        $idSeller = $params['id_seller'];
        if ($idSeller) {
            WkMpHyperlocalShipArea::deleteShipAreaByIdSeller($idSeller);
            WkMpHyperlocalShipRate::deleteShipRateByIdSeller($idSeller);
        }
    }

    public function hookActionFrontControllerSetMedia()
    {
        $cookie = new Cookie('wkhyperlocal_cookie');
        $display = false;
        if (!isset($cookie->wkHyperlocalAddress)) {
            $display = true;
        }

        Media::addJsDef(array(
            'wksetcustomerlocation' => $this->context->link->getModuleLink(
                'mphyperlocalsystem',
                'mpsetcustomerlocation'
            ),
            'display' => $display
        ));
        $language = $this->context->language;
        $country = $this->context->country;
        $mpGoogleApiKey = Configuration::get('WK_MP_GOOGLE_API_KEY');

        $this->context->controller->registerJavascript(
            'google-map-lib',
            "https://maps.googleapis.com/maps/api/js?key=$mpGoogleApiKey&libraries=places&language=$language->iso_code&region=$country->iso_code&region=$country->iso_code&v=3.31",
            array('server' => 'remote')
        );

        $this->context->controller->registerJavascript(
            'wk-setlocationJs',
            'modules/'.$this->name.'/views/js/wk-setlocation.js'
        );
    }

    /**
     * Update carrier id in our configuration when update in ps
     */
    public function hookupdateCarrier($params)
    {
        $idCarrier = $params['id_carrier'];
        $idHyperlocaclCarrier = Configuration::get('WK_MP_HYPERLOCAL_CARRIER_ID');
        if (isset($idCarrier) && $idCarrier && isset($idHyperlocaclCarrier)
        && $idHyperlocaclCarrier && $idHyperlocaclCarrier == $idCarrier) {
            Configuration::updateValue('WK_MP_HYPERLOCAL_CARRIER_ID', (int) ($params['carrier']->id));
        }
    }

    public function createHyperlocalCarrier()
    {
        $carrier = new Carrier();
        $carrier->name = 'Hyperlocal';
        $carrier->id_tax_rules_group = 0;
        $carrier->id_zone = 1;
        $carrier->active = true;
        $carrier->deleted = 0;
        $carrier->shipping_handling = false;
        $carrier->range_behavior = 0;
        $carrier->is_module = true;
        $carrier->shipping_external = true;
        $carrier->external_module_name = 'mphyperlocalsystem';
        $carrier->need_range = true;

        $languages = Language::getLanguages(true);
        foreach ($languages as $language) {
            $carrier->delay[(int) $language['id_lang']] = 'Hyperlocal';
        }

        if ($carrier->add()) {
            $groups = Group::getGroups(true);
            foreach ($groups as $group) {
                Db::getInstance()->insert(
                    'carrier_group',
                    array(
                        'id_carrier' => (int) ($carrier->id),
                        'id_group' => (int) ($group['id_group']),
                    )
                );
            }

            $rangePrice = new RangePrice();
            $rangePrice->id_carrier = $carrier->id;
            $rangePrice->delimiter1 = '0';
            $rangePrice->delimiter2 = '10000';
            $rangePrice->add();

            $rangeWeight = new RangeWeight();
            $rangeWeight->id_carrier = $carrier->id;
            $rangeWeight->delimiter1 = '0';
            $rangeWeight->delimiter2 = '10000';
            $rangeWeight->add();

            $zones = Zone::getZones(true);
            foreach ($zones as $zone) {
                Db::getInstance()->insert(
                    'carrier_zone',
                    array(
                        'id_carrier' => (int) ($carrier->id),
                        'id_zone' => (int) ($zone['id_zone']),
                    )
                );
                Db::getInstance()->insert(
                    'delivery',
                    array(
                        'id_carrier' => (int) ($carrier->id),
                        'id_range_price' => (int) ($rangePrice->id),
                        'id_range_weight' => null,
                        'id_zone' => (int) ($zone['id_zone']),
                        'price' => '0',
                    ),
                    true
                );
                Db::getInstance()->insert(
                    'delivery',
                    array(
                        'id_carrier' => (int) ($carrier->id),
                        'id_range_price' => null,
                        'id_range_weight' => (int) ($rangeWeight->id),
                        'id_zone' => (int) ($zone['id_zone']),
                        'price' => '0',
                    ),
                    true
                );
            }

            copy(_PS_MODULE_DIR_.'mphyperlocalsystem/logo.png', _PS_SHIP_IMG_DIR_.'/'.(int) $carrier->id.'.jpg');
            // Return ID Carrier
            Configuration::updateValue('WK_MP_HYPERLOCAL_CARRIER_ID', (int) ($carrier->id));
            return true;
        }

        return false;
    }

    /**
     * Register all tthe hooks needed in the module.
     *
     * @return bool
     */
    public function registerPsHooks()
    {
        $hooks = array(
            'actionFrontControllerSetMedia',
            'displayMPMyAccountMenu',
            'displayMPMenuBottom',
            'displayNav1',
            'displayHeader',
            'updateCarrier',
            'actionOrderStatusPostUpdate',
            'actionShippingDistribution',
            'actionShippingDistributionCost',
            'displayProductButtons',
            'actionMpSellerDelete'
        );
        return $this->registerHook($hooks);
    }

    public function install()
    {
        $mpHyperLocalDb = new MpHyperlocalSystemDb();
        if (!parent::install()
            || !$mpHyperLocalDb->createTable()
            || !$this->callInstallTab()
            || !$this->registerPsHooks()
            || !$this->createHyperlocalCarrier()
            ) {
            return false;
        }

        return true;
    }

    public function enable($force_all = false)
    {
        $idHylCarrier = Configuration::get('WK_MP_HYPERLOCAL_CARRIER_ID');
        if ($idHylCarrier) {
            $carrier = new Carrier($idHylCarrier);
            $carrier->active = 1;
            $carrier->save();
        }

        return parent::enable($force_all);
    }

    public function disable($force_all = false)
    {
        $idHylCarrier = Configuration::get('WK_MP_HYPERLOCAL_CARRIER_ID');
        if ($idHylCarrier) {
            $carrier = new Carrier($idHylCarrier);
            $carrier->active = 0;
            $carrier->save();
        }

        return parent::disable($force_all);
    }


    public function callInstallTab()
    {
        $this->installTab('AdminManageHyperlocalSystem', 'Hyperlocal', 'AdminMarketplaceManagement');
        $this->installTab('AdminHyperlocalShipArea', 'Shipping Area', 'AdminManageHyperlocalSystem');
        $this->installTab('AdminHyperlocalShipRate', 'Shipping Rate', 'AdminManageHyperlocalSystem');

        return true;
    }

    public function installTab($className, $tabName, $tabParentName = false)
    {
        //creating tab in admin within marketplace tab
        $tab = new Tab();
        $tab->active = 1;
        $tab->class_name = $className;
        $tab->name = array();
        foreach (Language::getLanguages(false) as $lang) {
            $tab->name[$lang['id_lang']] = $tabName;
        }

        if ($tabParentName) {
            $tab->id_parent = (int) Tab::getIdFromClassName($tabParentName);
        } else {
            $tab->id_parent = 0;
        }

        $tab->module = $this->name;

        return $tab->add();
    }

    public function uninstallTab()
    {
        $moduleTabs = Tab::getCollectionFromModule($this->name);
        if (!empty($moduleTabs)) {
            foreach ($moduleTabs as $moduleTab) {
                if (!$moduleTab->delete()) {
                    return false;
                }
            }
        }

        return true;
    }

    public function deleteHyperlocalCarrier()
    {
        $idCarrier = Configuration::get('WK_MP_HYPERLOCAL_CARRIER_ID');
        if ($idCarrier) {
            $carrier = new Carrier((int) ($idCarrier));
            $carrier->delete();
        }

        return true;
    }

    public function deleteConfigVars()
    {
        $configKeys = array(
            'WK_MP_GOOGLE_API_KEY',
            'WK_MP_HYPERLOCAL_RADIUS_UNIT',
            'WK_MP_HYPERLOCAL_DISTANCE',
            'WK_MP_SHIP_AREA_ADMIN_APPROVE',
            'WK_MP_HYPERLOCAL_OUT_OF_RANGE',
            'WK_MP_HYPERLOCAL_OUT_OF_RANGE_PRICE',
            'WK_MP_HYPERLOCAL_CARRIER_ID'
         );

        foreach ($configKeys as $key) {
            if (!Configuration::deleteByName($key)) {
                return false;
            }
        }

        return true;
    }

    public function uninstall()
    {
        $cookie = new Cookie('wkhyperlocal_cookie');
        $cookie->logout();

        $mpHyperLocalDb = new MpHyperlocalSystemDb();
        if (!parent::uninstall()
            || !$mpHyperLocalDb->deleteTable()
            || !$this->deleteHyperlocalCarrier()
            || !$this->deleteConfigVars()
            || !$this->uninstallTab()) {
            return false;
        }

        return true;
    }
}
